const fs = require('node:fs')
const f = process.argv[2]
const j = JSON.parse(fs.readFileSync(f, 'utf8'))

console.log('== FREE models (credit 0 or free-ish)')
for (const m of j.models || []) {
  const c = String(m.credit ?? '')
  if (c.includes('0.00') || /free/i.test(String(m.name)) || /free/i.test(String(m.id))) {
    console.log('  ', m.id, '|', m.name, '| credit:', c)
  }
}

console.log('\n== full model objects for hy4free/hy3')
for (const m of j.models || []) {
  if (['hy4free', 'hy3', 'default-model', 'deepseek-v4.1-flash-sg'].includes(m.id)) {
    console.log(JSON.stringify(m, null, 2))
  }
}

console.log('\n== authentication full')
console.log(JSON.stringify(j.authentication, null, 2).slice(0, 3000))

console.log('\n== completion')
console.log(JSON.stringify(j.completion, null, 2).slice(0, 1500))

console.log('\n== config (paths)')
console.log(JSON.stringify(j.config, null, 2).slice(0, 1500))

console.log('\n== networkEnvironment')
console.log(JSON.stringify(j.networkEnvironment, null, 2).slice(0, 800))
