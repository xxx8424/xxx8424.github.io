// Minimal ASAR reader. Header layout quirks: u32@8 is jsonLen+5, so locate the real
// JSON end by brace matching from the first '{' at offset 16.
import fs from 'node:fs'
import path from 'node:path'

const [, , asarPath, outDir, patternArg, mode] = process.argv
if (!asarPath) { console.error('usage: asar-extract.mjs <asar> <outdir> [regex|-] [list|extract]'); process.exit(1) }
const pattern = patternArg && patternArg !== '-' ? new RegExp(patternArg, 'i') : null
const doExtract = (mode || 'list') === 'extract'

const fd = fs.openSync(asarPath, 'r')
const head = Buffer.alloc(16)
fs.readSync(fd, head, 0, 16, 0)
const declared = head.readUInt32LE(8)
// Read a generous slab and brace-match.
let slabSize = declared + 64
let slab = Buffer.alloc(slabSize)
fs.readSync(fd, slab, 0, slabSize, 16)
let jsonEnd = -1
if (slab[0] === 0x7b) {
  let depth = 0, inStr = false, esc = false
  for (let i = 0; i < slab.length; i++) {
    const c = slab[i]
    if (inStr) {
      if (esc) esc = false
      else if (c === 0x5c) esc = true
      else if (c === 0x22) inStr = false
      continue
    }
    if (c === 0x22) inStr = true
    else if (c === 0x7b) depth++
    else if (c === 0x7d) { depth--; if (depth === 0) { jsonEnd = i + 1; break } }
  }
}
if (jsonEnd < 0) { console.error('could not locate JSON end'); process.exit(1) }
const header = JSON.parse(slab.subarray(0, jsonEnd).toString('utf8'))
const baseOffset = 16 + jsonEnd
console.log(`jsonEnd=${jsonEnd} declared=${declared} baseOffset=${baseOffset} size=${fs.statSync(asarPath).size}`)

const entries = []
function walk(node, prefix) {
  for (const [name, val] of Object.entries(node.files || {})) {
    const p = prefix ? `${prefix}/${name}` : name
    if (val.files) walk(val, p)
    else entries.push({ path: p, size: Number(val.size || 0), offset: val.offset, unpacked: !!val.unpacked })
  }
}
walk(header, '')
console.log(`files=${entries.length}`)

const hits = pattern ? entries.filter(e => pattern.test(e.path)) : entries
if (!doExtract) {
  console.log(`matched=${hits.length}`)
  for (const e of hits.slice(0, 500)) console.log(`${String(e.size).padStart(10)}  ${e.path}`)
} else {
  let n = 0
  for (const e of hits) {
    if (e.size > 40 * 1024 * 1024) { console.log('skip big', e.path); continue }
    const dest = path.join(outDir, e.path)
    fs.mkdirSync(path.dirname(dest), { recursive: true })
    if (e.unpacked) fs.copyFileSync(path.join(asarPath + '.unpacked', e.path), dest)
    else {
      const buf = Buffer.alloc(e.size)
      if (e.size > 0) fs.readSync(fd, buf, 0, e.size, baseOffset + Number(e.offset))
      fs.writeFileSync(dest, buf)
    }
    n++
  }
  console.log(`extracted ${n}`)
}
fs.closeSync(fd)
