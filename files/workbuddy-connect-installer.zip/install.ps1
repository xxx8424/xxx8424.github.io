# WorkBuddy Connect - one-click installer for DeepSeek Harness
# Finds the DSH profile, installs @venshell/dsh-workbuddy-connect via DSH's bundled pnpm,
# then registers it in dsh.profile.bundles.

$ErrorActionPreference = 'Stop'
Write-Host ""
Write-Host "=== WorkBuddy Connect installer ===" -ForegroundColor Cyan
Write-Host ""

# 1) locate DSH profile
$profilesRoot = Join-Path $env:USERPROFILE ".dsh\profiles"
$profile = $null
if (Test-Path $profilesRoot) {
    foreach ($d in Get-ChildItem $profilesRoot -Directory) {
        $pj = Join-Path $d.FullName "package.json"
        if (-not (Test-Path $pj)) { continue }
        try {
            $j = Get-Content $pj -Raw | ConvertFrom-Json
            if ($j.dsh -and $j.dsh.profile) { $profile = $d.FullName; break }
        } catch { }
    }
}
if (-not $profile) {
    Write-Host "[ERROR] DSH profile not found under %USERPROFILE%\.dsh\profiles\*" -ForegroundColor Red
    Write-Host "        Install and launch DeepSeek Harness first." -ForegroundColor Red
    Read-Host "Press Enter to exit"
    exit 1
}
Write-Host "[OK] profile: $profile"

# 2) locate DSH bundled node + pnpm
$rtRoot = Join-Path $env:USERPROFILE ".dsh\dsh-runtimes"
$node = $null; $pnpm = $null
if (Test-Path $rtRoot) {
    $node = Get-ChildItem $rtRoot -Recurse -File -Filter "node.exe" -ErrorAction SilentlyContinue | Select-Object -First 1
    $pnpm = Get-ChildItem $rtRoot -Recurse -File -Filter "pnpm.cjs" -ErrorAction SilentlyContinue | Where-Object { $_.FullName -match '\\pnpm\\bin\\pnpm\.cjs$' } | Select-Object -First 1
}
if (-not $node -or -not $pnpm) {
    Write-Host "[ERROR] DSH bundled node/pnpm not found. Launch DSH once first." -ForegroundColor Red
    Read-Host "Press Enter to exit"
    exit 1
}
Write-Host "[OK] node: $($node.FullName)"

# 3) install package via DSH's pnpm
$store = Join-Path $env:LOCALAPPDATA "pnpm\store\v11"
Push-Location $profile
try {
    & $node.FullName $pnpm.FullName add "@venshell/dsh-workbuddy-connect@0.8.4" "--store-dir" $store
    $code = $LASTEXITCODE
} finally {
    Pop-Location
}
if ($code -ne 0) {
    Write-Host "[ERROR] pnpm add failed (exit $code). Check your network and retry." -ForegroundColor Red
    Read-Host "Press Enter to exit"
    exit 1
}
Write-Host "[OK] package installed"

# 4) register the bundle in dsh.profile.bundles
$pj = Join-Path $profile "package.json"
$bak = "$pj.bak-" + (Get-Date -Format "yyyyMMdd-HHmmss")
Copy-Item $pj $bak -Force
$j = Get-Content $pj -Raw | ConvertFrom-Json
$bundles = @($j.dsh.profile.bundles)
if ($bundles -notcontains "@venshell/dsh-workbuddy-connect") {
    $bundles += "@venshell/dsh-workbuddy-connect"
    $j.dsh.profile.bundles = $bundles
    $json = $j | ConvertTo-Json -Depth 30
    [System.IO.File]::WriteAllText($pj, $json, (New-Object System.Text.UTF8Encoding($false)))
    Write-Host "[OK] added to dsh.profile.bundles (backup: $bak)"
} else {
    Write-Host "[OK] already in dsh.profile.bundles"
}

Write-Host ""
Write-Host "=== DONE ===" -ForegroundColor Green
Write-Host "Restart DeepSeek Harness. A 'WorkBuddy AI' group should appear in the model selector."
Write-Host "(Requires the WorkBuddy AI international app to be signed in.)"
Write-Host ""
Read-Host "Press Enter to exit"
