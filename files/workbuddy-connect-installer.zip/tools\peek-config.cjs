const fs = require('node:fs')
const files = process.argv.slice(2)
for (const f of files) {
  let j
  try { j = JSON.parse(fs.readFileSync(f, 'utf8')) } catch (e) { console.log(f, 'PARSE FAIL', e.message); continue }
  const pick = ['endpoint', 'stagingEndpoint', 'isOversea', 'deploymentType', 'websiteHomeUrl', 'updateUrl', 'productName', 'productId', 'authentication', 'version']
  console.log('==', f)
  for (const k of pick) {
    if (j[k] !== undefined) console.log('  ', k, '=', typeof j[k] === 'object' ? JSON.stringify(j[k]).slice(0, 400) : j[k])
  }
  console.log('   toplevel keys:', Object.keys(j).slice(0, 40).join(', '))
}
