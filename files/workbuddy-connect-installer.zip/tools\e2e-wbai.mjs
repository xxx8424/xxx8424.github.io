// End-to-end: decrypt the intl access token with the app's own Electron, then
// ask the FREE model (hy4free) for a one-word answer. Proves free tier works.
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import crypto from 'node:crypto'
import { execFile } from 'node:child_process'

const AUTH = path.join(os.homedir(), 'AppData', 'Local', 'CodeBuddyExtension', 'Data', 'Public', 'auth', 'workbuddy-desktop-ai.info')
const ELECTRON = path.join(process.env.LOCALAPPDATA, 'Programs', 'WorkBuddyAI', 'WorkBuddyAI.exe')
const BASE = 'https://www.workbuddy.ai'
const model = process.argv[2] || 'hy4free'

const HELPER = 'process.stdout.write(String(process._linkedBinding("electron_browser_workbuddy_storage").loggerGet()))'

function runHelper() {
  return new Promise((resolve, reject) => {
    execFile(ELECTRON, ['-e', HELPER], {
      timeout: 30000, maxBuffer: 1 << 20, windowsHide: true,
      env: { ...process.env, ELECTRON_RUN_AS_NODE: '1' },
    }, (err, stdout) => {
      if (err) return reject(new Error(`helper failed: ${err.message}`))
      resolve(stdout.trim())
    })
  })
}

const buildAad = (keyId, suite) => {
  const lp = (v) => { const b = Buffer.from(v, 'utf8'); const h = Buffer.allocUnsafe(4); h.writeUInt32BE(b.length); return Buffer.concat([h, b]) }
  const s = Buffer.allocUnsafe(4); s.writeUInt32BE(suite)
  return Buffer.concat([Buffer.from('WB-AAD\0', 'ascii'), Buffer.from([1]), lp('WBEV1'), lp('sym-v1'), s, lp(keyId), Buffer.from([2]), Buffer.from([0]), Buffer.from([0])])
}

function openField(key, b64) {
  const env = JSON.parse(Buffer.from(b64, 'base64').toString('utf8'))
  const d = crypto.createDecipheriv('aes-256-gcm', key, Buffer.from(env.nonce, 'base64'), { authTagLength: 16 })
  d.setAAD(buildAad(env.keyId, env.suite))
  d.setAuthTag(Buffer.from(env.authTag, 'base64'))
  return Buffer.concat([d.update(Buffer.from(env.ciphertext, 'base64')), d.final()]).toString('utf8')
}

const doc = JSON.parse(fs.readFileSync(AUTH, 'utf8'))
const secretText = await runHelper()
const payload = JSON.parse(secretText)
const key = crypto.createHash('sha256').update(payload.atRestSecretKey, 'utf8').digest()
console.log('at-rest secret resolved; keyId ok =', payload.version === 1)

const token = openField(key, doc.auth.accessToken.envelope)
const account = doc.account || {}
console.log('decrypted token len =', token.length)
console.log('domain =', doc.auth.domain, '| uid =', account.uid, '| type =', account.type)

const uuid = () => crypto.randomUUID()
const traceId = crypto.randomBytes(16).toString('hex')
const spanId = crypto.randomBytes(8).toString('hex')
const parent = crypto.randomBytes(8).toString('hex')

const headers = {
  'Accept': 'application/json, text/plain, */*',
  'Content-Type': 'application/json',
  'Authorization': `Bearer ${token}`,
  'X-Requested-With': 'XMLHttpRequest',
  'Origin': BASE,
  'Referer': `${BASE}/`,
  'User-Agent': 'CLI/2.63.2 CodeBuddy/2.63.2',
  'X-User-Id': account.uid,
  'X-No-Enterprise-Id': '1',
  'X-Domain': doc.auth.domain,
  'X-IDE-Type': 'WorkBuddy',
  'X-IDE-Name': 'WorkBuddy',
  'X-Conversation-ID': uuid(),
  'X-Conversation-Request-ID': uuid(),
  'X-Conversation-Message-ID': uuid(),
  'X-Request-ID': uuid(),
  'X-Private-Data': 'true',
  'x-codebuddy-request': '1',
  'traceparent': `00-${traceId}-${spanId}-01`,
  'b3': `${traceId}-${spanId}-1-${parent}`,
  'X-B3-TraceId': traceId,
  'X-B3-ParentSpanId': parent,
  'X-B3-SpanId': spanId,
  'X-B3-Sampled': '1',
  'X-Trace-ID': traceId,
}

const body = {
  model,
  stream: true,
  messages: [
    { role: 'system', content: 'You are a helpful assistant.' },
    { role: 'user', content: 'Reply with exactly one word: PONG' },
  ],
  max_tokens: 64,
}
console.log(`\n>>> POST ${BASE}/v2/chat/completions  model=${model}`)
const t0 = Date.now()
const res = await fetch(`${BASE}/v2/chat/completions`, { method: 'POST', headers, body: JSON.stringify(body) })
console.log('status =', res.status, '| ct =', res.headers.get('content-type'), `| ${Date.now() - t0}ms`)

if (!res.ok) {
  console.log('BODY:', (await res.text()).slice(0, 1500))
  process.exit(3)
}

const reader = res.body.getReader()
const dec = new TextDecoder()
let raw = ''
const deadline = Date.now() + 60000
while (Date.now() < deadline) {
  const { done, value } = await reader.read()
  if (done) break
  raw += dec.decode(value, { stream: true })
  if (/\[DONE\]/.test(raw)) break
  if (raw.length > 400000) break
}
try { await reader.cancel() } catch {}

console.log('\n--- raw stream (first 1200 chars) ---')
console.log(raw.slice(0, 1200))

// Pull out the assistant text from SSE deltas.
const pieces = []
const think = []
for (const line of raw.split('\n')) {
  const s = line.trim()
  if (!s.startsWith('data:')) continue
  const d = s.slice(5).trim()
  if (d === '[DONE]') continue
  try {
    const j = JSON.parse(d)
    const delta = j.choices?.[0]?.delta
    if (!delta) continue
    if (typeof delta.content === 'string' && delta.content) pieces.push(delta.content)
    if (typeof delta.reasoning_content === 'string' && delta.reasoning_content) think.push(delta.reasoning_content)
  } catch {}
}
console.log('\n=== REASONING (length ' + think.join('').length + ') ===')
console.log(think.join('').slice(0, 400))
console.log('\n=== ASSISTANT TEXT ===')
console.log(pieces.join('') || '(empty — model may be reasoning-only)')
