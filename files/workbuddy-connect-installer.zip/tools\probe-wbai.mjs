// Probe: does hy4free (free tier) actually respond on the WorkBuddy AI (intl) account?
// Reads the desktop app's own auth file (read-only) and calls /v2/chat/completions.
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import crypto from 'node:crypto'

const AUTH = path.join(os.homedir(), 'AppData', 'Local', 'CodeBuddyExtension', 'Data', 'Public', 'auth', 'workbuddy-desktop-ai.info')
const BASE = 'https://www.workbuddy.ai'
const model = process.argv[2] || 'hy4free'

const doc = JSON.parse(fs.readFileSync(AUTH, 'utf8'))
const auth = doc.auth || {}
const account = doc.account || {}
const token = auth.accessToken
console.log('domain      =', auth.domain)
console.log('tokenType   =', auth.tokenType)
console.log('expiresAt   =', new Date(Number(auth.expiresAt)).toISOString())
console.log('uid         =', account.uid)
console.log('accountType =', account.type)
console.log('tokenPresent=', typeof token === 'string' && token.length > 0, 'len=', token?.length)
if (!token) { console.error('NO TOKEN'); process.exit(1) }

const uuid = () => crypto.randomUUID()
const traceId = crypto.randomBytes(16).toString('hex')
const spanId = crypto.randomBytes(8).toString('hex')
const parentSpanId = crypto.randomBytes(8).toString('hex')

const headers = {
  'Accept': 'application/json, text/plain, */*',
  'Content-Type': 'application/json',
  'Authorization': `Bearer ${token}`,
  'X-Requested-With': 'XMLHttpRequest',
  'Origin': BASE,
  'Referer': `${BASE}/`,
  'User-Agent': 'CLI/2.63.2 CodeBuddy/2.63.2',
  'X-User-Id': account.uid || '',
  'X-No-Enterprise-Id': '1',
  'X-Domain': auth.domain || '',
  'X-IDE-Type': 'WorkBuddy',
  'X-IDE-Name': 'WorkBuddy',
  'X-Conversation-ID': uuid(),
  'X-Conversation-Request-ID': uuid(),
  'X-Conversation-Message-ID': uuid(),
  'X-Request-ID': uuid(),
  'X-Private-Data': 'true',
  'x-codebuddy-request': '1',
  'traceparent': `00-${traceId}-${spanId}-01`,
  'b3': `${traceId}-${spanId}-1-${parentSpanId}`,
  'X-B3-TraceId': traceId,
  'X-B3-ParentSpanId': parentSpanId,
  'X-B3-SpanId': spanId,
  'X-B3-Sampled': '1',
  'X-Trace-ID': traceId,
}

const body = {
  model,
  stream: true,
  messages: [{ role: 'user', content: 'Reply with exactly: OK' }],
  max_tokens: 32,
}

console.log('\n--- POST', `${BASE}/v2/chat/completions`, 'model =', model)
const started = Date.now()
let res
try {
  res = await fetch(`${BASE}/v2/chat/completions`, { method: 'POST', headers, body: JSON.stringify(body) })
} catch (e) {
  console.error('NETWORK ERROR:', e.message)
  process.exit(2)
}
console.log('status =', res.status, 'content-type =', res.headers.get('content-type'), `(${Date.now() - started}ms)`)

if (!res.ok) {
  const text = await res.text()
  console.log('BODY:', text.slice(0, 1200))
  process.exit(3)
}

// Stream a bounded amount.
const reader = res.body.getReader()
const dec = new TextDecoder()
let out = ''
let events = 0
while (events < 40) {
  const { done, value } = await reader.read()
  if (done) break
  out += dec.decode(value, { stream: true })
  events++
  if (/\bOK\b/.test(out)) { try { reader.cancel() } catch {} break }
}
console.log('\n--- first stream chunk ---')
console.log(out.slice(0, 2000))
