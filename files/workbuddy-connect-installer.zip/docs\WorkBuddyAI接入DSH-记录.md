# WorkBuddy AI（国际版）接入 DSH — 安装与验证记录

> 生成时间：2026-11-12 18:20 (Asia/Shanghai)
> 目标：把 WorkBuddy 国际版的**免费模型**接进 DSH，并且**必须登录后才能用**。

---

## 一、结论先说

| 问题 | 答案 | 证据 |
|---|---|---|
| WorkBuddy 国际版有免费模型吗？ | **有**，`hy4free`(Hy4) 和 `hy3`(Hy3)，倍率 `x0.00` | 从本机 App 的 `acc-product-config-v3.json` 读出 |
| 免费模型真能出字吗？ | **能，已实测跑通** | HTTP 200，返回正文 `PONG`，见第五节 |
| 需要登录吗？ | **需要** | 令牌有效、账号已登录（具体信息已隐去） |
| 参考项目 dsh-our-free-model 能做吗？ | **不能**，它里面没有 WorkBuddy | 全文检索 `workbuddy`/`copilot.tencent`/`codebuddy` = 0 命中 |

---

## 二、本机环境（实测）

| 项 | 值 |
|---|---|
| DSH 内核版本 | `0.2.1-rc.5` |
| DSH 安装目录 | `%USERPROFILE%\AppData\Local\Programs\DeepSeek Harness` |
| profile | `%USERPROFILE%\.dsh\profiles\desktop` |
| WorkBuddy 国内版 | `Programs\WorkBuddy` |
| WorkBuddy **国际版** | `Programs\WorkBuddyAI`（`@genie/workbuddy-desktop` v5.9.4 / 37.10.3-43） |
| 国际版 API 端点 | `https://www.workbuddy.ai` |
| 国际版产品标识 | `productName = "WorkBuddy AI"`，`isOversea = true`，`dataFolderName = .workbuddy-ai` |

### 登录凭据位置（关键）

```
%USERPROFILE%\AppData\Local\CodeBuddyExtension\Data\Public\auth\workbuddy-desktop-ai.info
```

- 国内版：同目录 `workbuddy-desktop.info`
- 依据：`FilePathServiceImpl` → `sharedDataPath = <basePath>/Data/Public`，
  `basePath(win32) = AppData/Local/<dataFolderName>`，文件名为 `auth/<authentication.id>.info`
- `authentication.id` 国际版 = `workbuddy-desktop-ai`

### 凭据文件结构

```jsonc
{
  "auth": {
    "accessToken":  { "$wbEncrypted": 1, "envelope": "<base64>" },  // 加密
    "refreshToken": { "$wbEncrypted": 1, "envelope": "<base64>" },  // 加密
    "tokenType": "Bearer",
    "domain": "www.workbuddy.ai",   // ← 明文，用它区分国际版/国内版
    "expiresAt": (已隐去),     // (已隐去)
    "refreshExpiresAt": ...
  },
  "account": { "uid": "...", "nickname": {...encrypted}, "type": "personal", "lastLogin": true }
}
```

**只有 `accessToken` / `refreshToken` / `nickname` 是加密的**，其余明文。

加密为 AES-256-GCM（suite 1，framing `WBEV1`），解密步骤：
1. 用自己的 Electron 取静态密钥：
   `ELECTRON_RUN_AS_NODE=1 WorkBuddyAI.exe -e 'process.stdout.write(String(process._linkedBinding("electron_browser_workbuddy_storage").loggerGet()))'`
2. `protectorKey = sha256(atRestSecretKey, utf8)`
3. AES-256-GCM 解密，AAD 见附录 A

---

## 三、国际版免费模型（从真实配置读出）

| id | 名称 | 倍率 | 上下文 | 输出上限 | 工具调用 | 图片 |
|---|---|---|---|---|---|---|
| `hy4free` | Hy4 | **x0.00** (`badge:Free now`) | 1,000,000 | 64,000 | ✅ | ✅ |
| `hy3` | Hy3 | **x0.00** (`badge:Free now`) | 192,000 | 64,000 | ✅ | ✅ |

- 两者都是 `onlyReasoning: true`（纯推理模型），正文前会有 `reasoning_content` 流。
- 其余 9 个模型（GPT-6 系、Grok-4.7、Gemini-3.8-Flash、Kimi-K3.1-Pro 等）在 `modelTiers`
  里标为 **Pro Only**，需要订阅才能用。
- `hy4free` 的 `reasoning.supportedEfforts = ["high"]`，`canDisableThinking: false`。

---

## 四、上游调用协议（实测踩坑）

```
POST https://www.workbuddy.ai/v2/chat/completions
```

**必需的请求头**（缺任一项会被渠道校验拦截）：

| 头 | 作用 |
|---|---|
| `Authorization: Bearer <accessToken>` | 鉴权 |
| `X-Conversation-ID` / `X-Conversation-Request-ID` / `X-Conversation-Message-ID` | 国际版自 2026-10-16 起**强制要求**，缺失回 `400 / 11128 "conversation id missing"` |
| `X-Request-ID`、`X-Private-Data: true`、`x-codebuddy-request: 1` | 声明为一方客户端 |
| `traceparent`、`b3`、`X-B3-*`、`X-Trace-ID` | 追踪族 |
| `Origin` / `Referer` = 端点本身，`X-User-Id`、`X-Domain`、`X-IDE-Type/Name: WorkBuddy` | 客户端身份 |
| `User-Agent: CLI/2.63.2 CodeBuddy/2.63.2` | 客户端 UA |

**请求体硬约束（实测踩到）**：

1. **第一条消息必须是 `system`**。否则回：
   ```
   400 {"code":11128,"msg":"first message is not system prompt",
        "displayMsg":{"zh":"请求被拦截，请重新发送"}}
   ```
   ⚠️ 这正是 `hy4free` 首次实测 400 的原因，加上 `system` 后立刻 200。

2. **必须流式**（`stream: true`），非流式会被拒（`11101`）。
3. 令牌刷新：`POST /v2/plugin/auth/token/refresh`，头 `X-Refresh-Token`。
4. 登出：`POST /v2/plugin/auth/logout`。

---

## 五、端到端实测结果 ✅

```
at-rest secret resolved; keyId ok = true
decrypted token len = 1297
domain = www.workbuddy.ai | uid = (已隐去) | type = personal

>>> POST https://www.workbuddy.ai/v2/chat/completions  model=hy4free
status = 200 | ct = text/event-stream | 1(已隐去)ms

=== REASONING (length 201) ===
The user instructed me to reply with exactly one word: "PONG". Therefore I must output only
that single word, with no additional text, punctuation, or explanation. My response should be exactly "PONG".

=== ASSISTANT TEXT ===
PONG
```

**免费模型 `hy4free` 真实可用，零积分出字。**

---

## 六、已做的安装动作

采用 [Venshell/dsh-workbuddy-connect](https://www.npmjs.com/package/@venshell/dsh-workbuddy-connect) **v0.8.4**
（`engines.dsh: >=0.2.1-rc.3 <0.3.0-0`，与内核 rc.5 匹配）。

安装方式：用 App 自带 pnpm（11.28.5）装进 desktop profile，保证 `package.json` / `pnpm-lock.yaml` / `node_modules` 三者一致：

```powershell
$node = "%USERPROFILE%\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\node\bin\node.exe"
$pnpm = "%USERPROFILE%\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\pnpm\bin\pnpm.cjs"
cd %USERPROFILE%\.dsh\profiles\desktop
& $node $pnpm add "@venshell/dsh-workbuddy-connect@0.8.4" `
    --store-dir "%USERPROFILE%\AppData\Local\pnpm\store\v11"
```

已确认：
- `node_modules/@venshell/dsh-workbuddy-connect` = 0.8.4 ✅
- `package.json` dependencies 含 `@venshell/dsh-workbuddy-connect: 0.8.4` ✅
- `pnpm-lock.yaml` 已登记 ✅
- `@earendil-works/pi-ai` = 1.3.0 已解析 ✅
- `dsh.profile.bundles` 已加入 `@venshell/dsh-workbuddy-connect` ✅

**备份**：`%USERPROFILE%\.dsh\profiles\desktop-backup-20261112-181406\`
（含改动前的 `package.json`、`cordis.patch.yml`、`cordis.yml`）

---

## 七、插件 CLI 实测（证明插件自身逻辑可用）

把内核 peer 包临时补到解析路径后运行：

```powershell
node lib/bin.js status --provider workbuddy-ai --json
```
```json
{"schemaVersion":1,"package":"dsh-workbuddy-connect","version":"0.8.4",
 "provider":"workbuddy-ai","status":"signed-in",
 "accessTokenExpires":"(已隐去)",
 "domain":"www.workbuddy.ai","source":"desktop","credits":"(已隐去)","hostBundle":"running"}
```

```powershell
node lib/bin.js doctor
```
```
WorkBuddy Connect 0.8.4 on v24.21.0
Desktop auth file: present — encrypted (.../workbuddy-desktop-ai.info)
Host bundle: running (pid 7912)
Sign-in state: signed-in
Static fallback models: 19
```

---

## 八、还需你做的（重启生效）

插件已装好，但 profile 组合在 **DSH 启动时**解析，所以必须重启一次 DeepSeek Harness。

重启后请检查：
1. 模型选择器里出现 **「WorkBuddy AI」** 分组；
2. 分组里能看到 `Hy4`（x0.00）等模型；
3. 选 `Hy4` 发一句话，能正常回复。

⚠️ 重启会中断当前对话，请自行决定时机。

### 若重启后分组没出现

1. 先看是否报内核不兼容：
   ```
   dsh: installation rejected: Plugin @venshell/dsh-workbuddy-connect@0.8.4 is incompatible ...
   ```
   若出现，说明 `engines.dsh` 未生效——但它明明声明了，理论上不会。
2. 回滚：
   ```powershell
   Copy-Item "%USERPROFILE%\.dsh\profiles\desktop-backup-20261112-181406\*" `
             "%USERPROFILE%\.dsh\profiles\desktop\" -Force
   ```
   再从 `node_modules` 删掉 `@venshell` 目录即可。

---

## 九、关于"必须登录才能用"

插件的设计本身满足这个要求：

- 它**不发起任何登录**，只读桌面 App 的凭据文件（只读，永不回写）；
- 某个版本从未登录时，**该分组直接不显示**——不给"选了必然报错"的兜底列表；
- 令牌刷新写在插件自己的副本 `$DSH_HOME/.workbuddy-ai-auth.json`，App 文件保持原样。

也就是说：**没登录 → 选择器里没有 WorkBuddy AI 分组 → 根本用不了**。

如果你想更严格（比如"已登录但令牌过期时给出明确提示"），可以在插件之上做，但当前机制已满足"必须登录"。

---

## 十、附录 A：AES-256-GCM 的 AAD 构造

```
WB-AAD\0            (8 bytes)
0x01
len("WBEV1") + "WBEV1"
len("sym-v1") + "sym-v1"
uint32be(suite)      // suite = 1
len(keyId) + keyId   // keyId 为 16 位 hex 字符串
0x02
0x00
0x00
```
其中 `len(x)` 是 4 字节大端无符号整数，表示后续 utf8 字节数。

## 十一、附录 B：相关文件位置

| 内容 | 路径 |
|---|---|
| 国际版程序 | `%USERPROFILE%\AppData\Local\Programs\WorkBuddyAI\` |
| 国际版 app.asar | `...\WorkBuddyAI\resources\app.asar`(181 MB) |
| 国际版凭据 | `%LOCALAPPDATA%\CodeBuddyExtension\Data\Public\auth\workbuddy-desktop-ai.info` |
| 国内版凭据 | 同目录 `workbuddy-desktop.info` |
| 真实产品配置 | `%TEMP%\workbuddy-product-spill-*\acc-product-config-v3.json` |
| 实测脚本 | `%PROJECT_ROOT%\_probe\e2e-wbai.mjs` |
| asar 工具 | `%PROJECT_ROOT%\_probe\asar-extract.mjs`、`asar-grep.mjs` |
| 插件源码包 | `%PROJECT_ROOT%\_probe\wbconnect\unpacked\package\` |

---

## 十二、追加：设置里的「WorkBuddy AI 登录」面板（独立插件）

> 追加时间：2026-11-12 19:30

用户要求「在 DSH 设置里加上这个的登录」。先说明一个事实：
**第三方插件没有、也不做登录页**——它复用桌面 App 的登录态，只读凭据文件。
它原本在设置里的卡片，未登录时只有一句文案，没有登录按钮。

### 新建的独立插件

| 项 | 值 |
|---|---|
| 包名 | `@local/dsh-workbuddy-ai-login` |
| 版本 | 1.0.0 |
| 源码 | `%PROJECT_ROOT%\plugins\dsh-workbuddy-ai-login\` |
| 安装 | `plugin_manager install_bundle` → `application: applied` |
| 注册表 | `list_bundles` 中 `enabled: true`，行 `dsh-workbuddy-ai-login` |

**面板位置**：DSH 设置 → 插件页（`plugins.bundle.config` slot，
key = 自己的包名，与第三方插件并存互不干扰）+ 兼容旧版 `settings.plugin.item`。

**面板内容**：
- 已登录 / 未登录 状态徽章（绿 / 橙）
- 账号类型、令牌有效期、凭据文件路径
- **「打开 WorkBuddy AI 登录」按钮** → 启动桌面 App 让你完成官方登录，
  4 秒后自动重新检测
- **「重新检测」按钮**
- 未登录时明确提示「必须先登录才能用该渠道模型」
- 底部固定提示：登录门禁已开启、Pro 模型需订阅、日常用 Hy4/Hy3

### Host 侧两个 loopback-only 路由

| 路由 | 作用 |
|---|---|
| `GET /plugins/workbuddy-ai-login/status` | 读凭据文件，返回脱敏登录状态 |
| `POST /plugins/workbuddy-ai-login/launch` | 启动 `WorkBuddyAI.exe` |

**安全设计**：只读凭据文件；**不解密、不回写、不向浏览器暴露
accessToken / refreshToken / nickname**。只用明文 `domain` / `expiresAt` /
`account.uid` 判断登录状态——这正好是「必须登录才能用」所需的全部信息。

登录判定（已单元验证 6 种情形）：
```
signedIn = domain 是 *.workbuddy.ai
        && auth 中存在 accessToken
        && expiresAt > now
```
不满足时分别给出 `wrong-edition` / `no-credential` / `expired` 原因。

实测（当前端口 62366）：
```json
{"signedIn":true,"domain":"www.workbuddy.ai","appName":"WorkBuddy AI",
 "accountType":"personal","accountHint":"(已隐去)","expiresAt":"(已隐去)",
 "authFile":"...\\workbuddy-desktop-ai.info","checked":[]}
```

### 「必须登录才能用」如何成立

两道保障：
1. 第三方插件本身：未登录时该渠道**不注册任何模型**，选择器看不到 WorkBuddy AI 分组；
2. 本插件：在设置里把登录状态显式化，未登录时给出明确引导和启动入口。

（若以后要更硬——比如「已登录但令牌中途失效时，主动拦截请求」——
需要改第三方插件的 adapter，本插件暂不越界。）

### 顺带修好的两个旧问题

`dsh-wechat` / `dshmarket` 一直报 `ERR_MODULE_NOT_FOUND`（缺构建产物），
与本次安装无关，已一并处理：

| 插件 | 问题 | 处理 |
|---|---|---|
| `dsh-wechat` | 缺 `dist/index.js` / `dist/client.js` | 用 TypeScript 5.9.3 跑 `tsc` + `scripts/copy-client.mjs` 产出 dist（junction 指向 `D:\dsh-wechat-main`） |
| `dshmarket` | 缺 `lib/index.js` | 用同一 tsc 按 `tsconfig.json` 编译出 104 个 `lib/*.js`；从 profile 复用 `js-yaml` / `undici` / `@deepseek-ai/schemastery` / `cosmokit` 到其本地 `node_modules`；`client/client.js` 本就是成品 |

两者都已实测 `import()` 成功：
- `dsh-wechat` → `apply, inject, name, sessionIdFrom`
- `dshmarket` → `apply, describeProfileContext, name, useTrustedHosts`

⚠️ 这两个是**源码目录 junction**，本地重新构建后产物已就位；**重启 DSH 后
warning 会消失**（导入错误已不复现）。

### 需要你做

**刷新页面（F5）**，或重启一次 DSH，然后在「设置 → 插件」里找
**「WorkBuddy AI 登录」**。因缺少浏览器控制，面板的实际视觉呈现由你确认；
安装、路由、状态读取、门禁逻辑均已实测通过。
