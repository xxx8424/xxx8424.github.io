// Unit-check the readState() verdict logic without touching the real plugin.
// We import the real module by copying its pure logic through a temp env override.
const fs = require('node:fs')
const path = require('node:path')
const os = require('node:os')

// Mirror of the plugin's readState, driven by WORKBUDDY_AI_AUTH_FILE.
function readState(files) {
  for (const file of files) {
    let text
    try { text = fs.readFileSync(file, 'utf8') } catch { continue }
    let doc
    try { doc = JSON.parse(text) } catch { continue }
    const auth = doc?.auth && typeof doc.auth === 'object' ? doc.auth : {}
    const account = doc?.account && typeof doc.account === 'object' ? doc.account : {}
    const domain = typeof auth.domain === 'string' ? auth.domain : ''
    const isInternational = domain === 'workbuddy.ai' || domain.endsWith('.workbuddy.ai')
    const hasToken = Object.prototype.hasOwnProperty.call(auth, 'accessToken') && auth.accessToken != null
    const expiresAt = Number(auth.expiresAt) || 0
    const expired = expiresAt > 0 && expiresAt <= Date.now()
    const signedIn = isInternational && hasToken && !expired
    return {
      signedIn,
      reason: signedIn ? undefined : !isInternational ? 'wrong-edition' : !hasToken ? 'no-credential' : 'expired',
      accountType: typeof account.type === 'string' ? account.type : undefined,
    }
  }
  return { signedIn: false, reason: 'no-credential' }
}

const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'wbai-gate-'))
const real = path.join(process.env.LOCALAPPDATA, 'CodeBuddyExtension', 'Data', 'Public', 'auth', 'workbuddy-desktop-ai.info')
const cases = [
  ['real signed-in', readState([real])],
  ['missing file', readState([path.join(dir, 'nope.info')])],
  ['CN edition', readState([(() => { const p = path.join(dir, 'cn.json'); fs.writeFileSync(p, JSON.stringify({ auth: { domain: 'www.workbuddy.cn', accessToken: 'x', expiresAt: Date.now() + 1e9 }, account: { type: 'personal' } })); return p })()])],
  ['no token', readState([(() => { const p = path.join(dir, 'notoken.json'); fs.writeFileSync(p, JSON.stringify({ auth: { domain: 'www.workbuddy.ai', expiresAt: Date.now() + 1e9 }, account: {} })); return p })()])],
  ['expired', readState([(() => { const p = path.join(dir, 'expired.json'); fs.writeFileSync(p, JSON.stringify({ auth: { domain: 'www.workbuddy.ai', accessToken: 'x', expiresAt: Date.now() - 1000 }, account: {} })); return p })()])],
  ['valid intl', readState([(() => { const p = path.join(dir, 'valid.json'); fs.writeFileSync(p, JSON.stringify({ auth: { domain: 'www.workbuddy.ai', accessToken: 'x', expiresAt: Date.now() + 1e9 }, account: { type: 'personal' } })); return p })()])],
]
for (const [name, r] of cases) console.log(name.padEnd(18), '=>', JSON.stringify(r))
fs.rmSync(dir, { recursive: true, force: true })
