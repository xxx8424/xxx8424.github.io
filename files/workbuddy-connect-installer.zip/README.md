# WorkBuddy AI 接入 DSH

> 把 **WorkBuddy AI（国际版）** 的免费模型接入 **DeepSeek Harness**，登录后即可在 DSH 里直接使用。

---

## 它是什么

一个 DSH 插件。安装后，DSH 的模型选择器里会多出 **「WorkBuddy AI」** 分组，里面是 WorkBuddy 国际版的免费模型；选中即可在 DSH 里对话，额度直接走你的 WorkBuddy 账号。

- **必须登录**：插件不发起登录，只读取 WorkBuddy 桌面 App 已登录的凭据；没登录时该分组直接不显示。
- **零配置**：不用填 key、不用配 endpoint，装好即用。

## 免费模型

| 模型 | 名称 | 倍率 | 上下文 | 输出上限 | 工具调用 | 图片 |
|---|---|---|---|---|---|---|
| `hy4free` | Hy4 | **x0.00**（免费）| 1,000,000 | 64,000 | ✅ | ✅ |
| `hy3` | Hy3 | **x0.00**（免费）| 192,000 | 64,000 | ✅ | ✅ |

> 其余模型（GPT 系、Grok、Gemini 等）需要订阅才能用。

## 下载

**[workbuddy-connect-installer.zip](https://xxx8424.github.io/files/workbuddy-connect-installer.zip)**

> 点上面这个加粗的名字，浏览器会直接开始下载压缩包。

## 一键安装

1. 下载并解压上面的压缩包
2. 双击 **`install.cmd`**
3. 重启 **DeepSeek Harness** → 模型选择器里出现 **「WorkBuddy AI」** 分组

**前提：**

- 电脑装了 **DeepSeek Harness**，并且**启动过一次**（脚本要用它自带的 node/pnpm）
- 本机装了 **WorkBuddy AI 国际版**并**已登录**（未登录则分组不出现）

## 也可以把这个压缩包交给 AI 安装

把压缩包直接发给你的 AI 编程助手，让它按 `install.ps1` 的逻辑操作即可，本质只有两步：

1. 用 DSH 自带的 pnpm 安装 `@venshell/dsh-workbuddy-connect@0.8.4`
2. 把 `@venshell/dsh-workbuddy-connect` 加进 DSH profile 的 `dsh.profile.bundles`

## 手动安装

```powershell
# 用 DSH 自带的 node + pnpm 安装
$node = Get-ChildItem "$env:USERPROFILE\.dsh\dsh-runtimes" -Recurse -Filter node.exe | Select-Object -First 1
$pnpm = Get-ChildItem "$env:USERPROFILE\.dsh\dsh-runtimes" -Recurse -Filter pnpm.cjs | Where-Object { $_.FullName -match '\\pnpm\\bin\\pnpm\.cjs$' } | Select-Object -First 1
cd "$env:USERPROFILE\.dsh\profiles\desktop"
& $node.FullName $pnpm.FullName add "@venshell/dsh-workbuddy-connect@0.8.4"
```

然后把 `@venshell/dsh-workbuddy-connect` 加进该 profile 的 `package.json` → `dsh.profile.bundles` 数组，重启 DSH。

## 原理（简述）

- 插件读取 WorkBuddy 桌面 App 的凭据文件（**只读，从不回写**），在 DSH 里注册一个模型提供方。
- 未登录时凭据不存在 → 分组不显示 → 无法使用，天然满足「必须登录」。
- 上游调用为 `POST https://www.workbuddy.ai/v2/chat/completions`：必须流式（`stream: true`）、首条消息必须是 `system`，并携带 `X-Conversation-ID` 等请求头。

## 附：设置里的「WorkBuddy AI 登录」面板

`login-panel/` 是本仓库自带的**独立小插件**（`@local/dsh-workbuddy-ai-login`）。第三方插件只复用桌面 App 登录态、设置里没有登录按钮；这个面板把登录状态显式化：

- 设置 → 插件页显示「已登录 / 未登录」徽章、账号类型、令牌有效期
- 未登录时提供「打开 WorkBuddy AI 登录」按钮（启动桌面 App 完成官方登录）与「重新检测」
- 只读凭据文件里的明文信息（`domain` / `expiresAt` / `uid`），**不解密、不回写、不向浏览器暴露令牌**

设计细节与安全取舍见 [`docs/WorkBuddyAI接入DSH-记录.md`](docs/WorkBuddyAI接入DSH-记录.md) 第十二节。

## 仓库内容

| 目录 | 说明 |
|---|---|
| `plugin/` | 第三方插件副本（`@venshell/dsh-workbuddy-connect` 0.8.4，MIT）|
| `login-panel/` | 设置里的登录面板插件（本仓库自带）|
| `install.cmd` / `install.ps1` | 一键安装主插件 |
| `tools/` | 接入协议探测脚本 |
| `docs/` | 完整技术记录（协议、踩坑、登录面板设计、旧插件修复）|
| `README.md` | 本说明 |

## 来源与许可

- 本仓库的 `plugin/` 是开源项目 **[@venshell/dsh-workbuddy-connect](https://github.com/Venshell/dsh-workbuddy-connect)** 的副本（作者 Corrine Hu，维护 Venshell，**MIT** 许可），版权归原作者，仅作归档与安装演示。详见 [THIRD_PARTY_NOTICES.txt](THIRD_PARTY_NOTICES.txt)。
- 本仓库的说明与安装脚本以 MIT 许可发布，见 [LICENSE](LICENSE)。
