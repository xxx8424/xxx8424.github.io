// Verify the FREE tier really answers: decrypt token via the app's own Electron, then chat.
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import crypto from 'node:crypto'
import { execFileSync } from 'node:child_process'

const AUTH = path.join(os.homedir(), 'AppData', 'Local', 'CodeBuddyExtension', 'Data', 'Public', 'auth', 'workbuddy-desktop-ai.info')
const ELECTRON = path.join(process.env.LOCALAPPDATA, 'Programs', 'WorkBuddyAI', 'WorkBuddyAI.exe')
const BASE = 'https://www.workbuddy.ai'
const model = process.argv[2] || 'hy4free'

// --- 1. helpers transcribed from the app's own scheme -----------------------
const aad = (keyId, suite) => {
  const lp = (v) => { const b = Buffer.from(v, 'utf8'); const h = Buffer.allocUnsafe(4); h.writeUInt32BE(b.length); return Buffer.concat([h, b]) }
  const s = Buffer.allocUnsafe(4); s.writeUInt32BE(suite)
  return Buffer.concat([
    Buffer.from('WB-AAD\0', 'ascii'), Buffer.from([1]),
    lp('WBEV1'), lp('sym-v1'), s, lp(keyId),
    Buffer.from([2]), Buffer.from([0]), Buffer.from([0]),
  ])
}

function openField(key, env) {
  const d = crypto.createDecipheriv('aes-256-gcm', key, env.nonce, { authTagLength: 16 })
  d.setAAD(aad(env.keyId, env.suite))
  d.setAuthTag(env.authTag)
  return Buffer.concat([d.update(env.ciphertext), d.final()]).toString('utf8')
}

// The Electron helper: run the app's binary as node and read its storage key.
const HELPER = `
const { app } = require('electron')
const out = {}
try {
  const binding = process.binding ? undefined : undefined
  // workbuddyStorage is exposed on the Electron private binding surface
  const b = process._linkedBinding ? process._linkedBinding('workbuddyStorage') : undefined
  out.hasBinding = !!b
  if (b && typeof b.getAtRestSecret === 'function') out.secret = b.getAtRestSecret()
  else if (b) out.keys = Object.keys(b)
} catch (e) { out.error = String(e && e.message || e) }
process.stdout.write(JSON.stringify(out))
app && app.quit && app.quit()
`

function runHelper() {
  const tmp = path.join(os.tmpdir(), `wb-key-${process.pid}.js`)
  fs.writeFileSync(tmp, HELPER, 'utf8')
  try {
    const res = execFileSync(ELECTRON, [tmp], {
      env: { ...process.env, ELECTRON_RUN_AS_NODE: '1' },
      encoding: 'utf8', timeout: 60000, windowsHide: true,
      stdio: ['ignore', 'pipe', 'pipe'],
    })
    return res
  } catch (e) {
    return `ERR: ${e.message}\nSTDOUT:${e.stdout}\nSTDERR:${e.stderr}`
  } finally {
    try { fs.unlinkSync(tmp) } catch {}
  }
}

const doc = JSON.parse(fs.readFileSync(AUTH, 'utf8'))
const wrapped = doc.auth.accessToken
if (typeof wrapped === 'string') { console.log('token is plaintext'); }
else {
  console.log('token is encrypted; probing key extraction…')
  const r = runHelper()
  console.log('helper output:', String(r).slice(0, 600))
  process.exit(0)
}
