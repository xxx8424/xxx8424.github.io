/* WorkBuddy AI Sign-in — Client half.
 * Registers a Settings panel (plugins.bundle.config + settings.plugin.item)
 * that shows whether the WorkBuddy AI desktop app is signed in, and offers a
 * button that launches the desktop app so the user can complete the official
 * sign-in there. CJS on purpose: the Web GUI loader expects module.exports.
 */
window.__ModuleLoader__.load({
  id: '@local/dsh-workbuddy-ai-login',
  factory(require) {
    const React = require('react')
    const h = React.createElement
    const { useState, useEffect, useCallback, useRef } = React

    const STATUS_PATH = '/plugins/workbuddy-ai-login/status'
    const LAUNCH_PATH = '/plugins/workbuddy-ai-login/launch'
    const NAMESPACE = 'settings.workbuddyAiLogin'

    const zh = {
      meta: { title: 'WorkBuddy AI 登录', description: '在设置里查看 WorkBuddy AI 登录状态；未登录时不能使用该渠道的模型。' },
      panelTitle: 'WorkBuddy AI 登录',
      intro: 'DSH 复用 WorkBuddy AI 桌面 App 的登录状态。登录在桌面 App 里完成，插件自动跟随；未登录时该渠道的模型不可用。',
      statusChecking: '正在检查登录状态…',
      statusSignedIn: '已登录',
      statusSignedOut: '未登录',
      signedInHint: 'WorkBuddy AI 已登录，免费模型（Hy4 / Hy3）可用。',
      signedOutHint: '尚未登录。请先在 WorkBuddy AI 桌面 App 里登录，登录后模型才会出现在选择器中。',
      reasonWrongEdition: '凭据不是国际版（WorkBuddy AI）。',
      reasonNoCredential: '未找到登录凭据文件（可能从未登录过）。',
      reasonExpired: '登录已过期，请在桌面 App 里重新登录。',
      reasonOther: '登录状态不可用。',
      accountType: '账号类型',
      tokenExpires: '令牌有效期至',
      authFile: '凭据文件',
      personal: '个人账号',
      launch: '打开 WorkBuddy AI 登录',
      launching: '正在启动…',
      launchHint: '点击后将启动桌面 App，请在其中完成登录，然后回到这里点「重新检测」。',
      launchOk: '已启动桌面 App，请在其中完成登录后点击「重新检测」。',
      launchFail: '启动失败：{message}',
      recheck: '重新检测',
      rechecking: '检测中…',
      readFail: '状态读取失败：{message}',
      freeOnlyNote: '提示：Pro 系列模型需要订阅；日常使用请选择 Hy4 / Hy3（x0.00）。',
      gateOn: '登录门禁：已开启 — 未登录时该渠道不提供模型。',
    }

    const en = {
      meta: { title: 'WorkBuddy AI Sign-in', description: 'See WorkBuddy AI sign-in state in Settings; models stay unavailable until signed in.' },
      panelTitle: 'WorkBuddy AI Sign-in',
      intro: 'DSH reuses the sign-in of the WorkBuddy AI desktop app. Sign in there and this plugin follows automatically; while signed out, this channel offers no models.',
      statusChecking: 'Checking sign-in…',
      statusSignedIn: 'Signed in',
      statusSignedOut: 'Not signed in',
      signedInHint: 'WorkBuddy AI is signed in; the free models (Hy4 / Hy3) are available.',
      signedOutHint: 'Not signed in yet. Sign in from the WorkBuddy AI desktop app first — models appear in the picker only afterwards.',
      reasonWrongEdition: 'The credential is not the international edition (WorkBuddy AI).',
      reasonNoCredential: 'No sign-in credential file was found (the app may never have been signed in).',
      reasonExpired: 'The sign-in expired. Please sign in again from the desktop app.',
      reasonOther: 'Sign-in state is unavailable.',
      accountType: 'Account type',
      tokenExpires: 'Token valid until',
      authFile: 'Credential file',
      personal: 'Personal',
      launch: 'Open WorkBuddy AI to sign in',
      launching: 'Launching…',
      launchHint: 'This starts the desktop app. Finish signing in there, then come back and press "Recheck".',
      launchOk: 'Desktop app launched. Sign in there, then press "Recheck".',
      launchFail: 'Could not launch: {message}',
      recheck: 'Recheck',
      rechecking: 'Checking…',
      readFail: 'Could not read status: {message}',
      freeOnlyNote: 'Note: Pro models require a subscription. Use Hy4 / Hy3 (x0.00) for everyday use.',
      gateOn: 'Sign-in gate: ON — no models from this channel while signed out.',
    }

    // ---- theme-token styles (Apple-like: generous space, restrained palette) ----
    const card = {
      padding: '20px 22px', borderRadius: 14,
      border: '1px solid var(--dsw-alias-border-subtle, rgba(127,127,127,.22))',
      background: 'var(--dsw-alias-surface-raised, transparent)',
      color: 'var(--dsw-alias-text-primary, inherit)',
      fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", system-ui, sans-serif',
      maxWidth: 680, boxSizing: 'border-box',
    }
    const row = { display: 'flex', alignItems: 'center', gap: 10, flexWrap: 'wrap' }
    const badgeBase = {
      display: 'inline-flex', alignItems: 'center', gap: 7,
      padding: '4px 11px', borderRadius: 999, fontSize: 13, fontWeight: 600,
      border: '1px solid transparent',
    }
    const badgeOk = { ...badgeBase, background: 'rgba(48,180,110,.14)', color: '#1f9d63', borderColor: 'rgba(48,180,110,.35)' }
    const badgeOff = { ...badgeBase, background: 'rgba(230,120,60,.14)', color: '#c2601f', borderColor: 'rgba(230,120,60,.35)' }
    const badgeWait = { ...badgeBase, background: 'rgba(127,127,127,.14)', color: 'var(--dsw-alias-text-secondary, #888)', borderColor: 'rgba(127,127,127,.3)' }
    const btn = {
      appearance: 'none', cursor: 'pointer', padding: '8px 15px', borderRadius: 9,
      fontSize: 13, fontWeight: 600, border: '1px solid var(--dsw-alias-border-subtle, rgba(127,127,127,.3))',
      background: 'var(--dsw-alias-button-primary-fill, #2f7cf6)', color: '#fff',
    }
    const btnGhost = {
      ...btn, background: 'transparent', color: 'var(--dsw-alias-text-primary, inherit)',
      borderColor: 'var(--dsw-alias-border-subtle, rgba(127,127,127,.35))',
    }
    const muted = { color: 'var(--dsw-alias-text-secondary, #888)', fontSize: 12.5, lineHeight: 1.6 }
    const kv = { display: 'grid', gridTemplateColumns: 'auto 1fr', gap: '6px 14px', marginTop: 14, fontSize: 13 }
    const dot = (color) => ({ width: 7, height: 7, borderRadius: '50%', background: color, display: 'inline-block' })

    function formatTime(ms, locale) {
      if (!ms) return '—'
      try { return new Date(ms).toLocaleString(locale === 'zh' ? 'zh-CN' : 'en-US') } catch { return String(ms) }
    }

    function Panel({ t, isZh, view }) {
      if (view === 'summary') return h('span', null, t('meta.description'))

      const [state, setState] = useState(undefined)
      const [error, setError] = useState(undefined)
      const [busy, setBusy] = useState(false)
      const [launching, setLaunching] = useState(false)
      const [notice, setNotice] = useState(undefined)
      const alive = useRef(true)
      useEffect(() => () => { alive.current = false }, [])

      const read = useCallback(async () => {
        setBusy(true)
        try {
          const r = await fetch(STATUS_PATH, { cache: 'no-store' })
          if (!r.ok) throw new Error('HTTP ' + r.status)
          const data = await r.json()
          if (alive.current) { setState(data); setError(undefined) }
        } catch (e) {
          if (alive.current) setError(String(e?.message || e))
        } finally { if (alive.current) setBusy(false) }
      }, [])

      useEffect(() => { read() }, [read])

      const onLaunch = useCallback(async () => {
        setLaunching(true); setNotice(undefined)
        try {
          const r = await fetch(LAUNCH_PATH, { method: 'POST' })
          const data = await r.json()
          if (!alive.current) return
          if (data.launched) {
            setNotice({ ok: true, text: t('launchOk') })
            // Give the user time to sign in; re-read after a short delay.
            setTimeout(() => { if (alive.current) read() }, 4000)
          } else {
            setNotice({ ok: false, text: t('launchFail', { message: data.message || data.error || 'unknown' }) })
          }
        } catch (e) {
          if (alive.current) setNotice({ ok: false, text: t('launchFail', { message: String(e?.message || e) }) })
        } finally { if (alive.current) setLaunching(false) }
      }, [read, t])

      const tf = (key, vars) => {
        let s = t(key)
        if (vars) for (const [k, v] of Object.entries(vars)) s = s.replace('{' + k + '}', v)
        return s
      }

      const signedIn = state?.signedIn === true
      let badge = h('span', { style: badgeWait }, h('span', { style: dot('#999') }), t('statusChecking'))
      if (state) {
        badge = signedIn
          ? h('span', { style: badgeOk }, h('span', { style: dot('#1f9d63') }), t('statusSignedIn'))
          : h('span', { style: badgeOff }, h('span', { style: dot('#c2601f') }), t('statusSignedOut'))
      }

      const reasonKey = state && !signedIn
        ? ({ 'wrong-edition': 'reasonWrongEdition', 'no-credential': 'reasonNoCredential', expired: 'reasonExpired' }[state.reason] || 'reasonOther')
        : undefined

      return h('div', { style: card },
        h('div', { style: { ...row, justifyContent: 'space-between', marginBottom: 12 } },
          h('h2', { style: { margin: 0, fontSize: 16, fontWeight: 650 } }, t('panelTitle')),
          badge),
        h('p', { style: { ...muted, margin: '0 0 16px' } }, t('intro')),

        // status line
        state ? h('div', { style: { padding: '12px 14px', borderRadius: 10, background: signedIn ? 'rgba(48,180,110,.08)' : 'rgba(230,120,60,.08)', marginBottom: 14 } },
          h('div', { style: { fontSize: 13.5, fontWeight: 600, marginBottom: 4 } },
            signedIn ? t('signedInHint') : t('signedOutHint')),
          reasonKey ? h('div', { style: muted }, t(reasonKey)) : null,
        ) : null,

        error ? h('div', { style: { ...muted, color: '#c2601f', marginBottom: 12 } }, tf('readFail', { message: error })) : null,

        // details when signed in
        signedIn ? h('div', { style: kv },
          h('span', { style: muted }, t('accountType')),
          h('span', null, state.accountType === 'personal' ? t('personal') : (state.accountType || '—')),
          h('span', { style: muted }, t('tokenExpires')),
          h('span', null, formatTime(state.expiresAt, isZh ? 'zh' : 'en')),
        ) : null,

        // actions
        h('div', { style: { ...row, marginTop: 18 } },
          h('button', { type: 'button', style: btn, disabled: launching, onClick: onLaunch },
            launching ? t('launching') : t('launch')),
          h('button', { type: 'button', style: btnGhost, disabled: busy, onClick: read },
            busy ? t('rechecking') : t('recheck')),
        ),
        h('p', { style: { ...muted, marginTop: 10 } }, t('launchHint')),

        notice ? h('p', { style: { ...muted, marginTop: 8, color: notice.ok ? '#1f9d63' : '#c2601f' } }, notice.text) : null,

        h('div', { style: { borderTop: '1px solid var(--dsw-alias-border-subtle, rgba(127,127,127,.18))', marginTop: 18, paddingTop: 12 } },
          h('p', { style: { ...muted, margin: '0 0 4px' } }, t('gateOn')),
          h('p', { style: { ...muted, margin: 0 } }, t('freeOnlyNote')),
        ),
      )
    }

    /** Degrade one contribution to a console error; never throw into the loader. */
    const NOOP = () => {}
    function guarded(label, fn) {
      try { return fn() ?? NOOP } catch (error) {
        try { console.error('[dsh-workbuddy-ai-login] contribution failed:', label, error) } catch {}
        return NOOP
      }
    }

    return {
      inject: ['slots', 'locale'],
      apply(ctx) {
        guarded('locale', () => ctx.effect(() => ctx.locale.register(NAMESPACE, { zh, en }),
          'dsh-workbuddy-ai-login: locale'))
        let t
        guarded('locale bind', () => { t = ctx.locale.bind(NAMESPACE) })
        if (!t) return
        const isZh = typeof navigator !== 'undefined' && /^zh\b/i.test(navigator.language || '')
        const Comp = (props) => h(Panel, { ...props, t, isZh })

        // Both seams exist across DSH generations; each is guarded independently
        // so a missing declaration cannot drop the other one or the Host routes.
        guarded('plugins.bundle.config', () => ctx.slots.inject('plugins.bundle.config',
          () => guarded('plugins.bundle.config register', () => ctx.slots.register({
            name: 'plugins.bundle.config',
            key: '@local/dsh-workbuddy-ai-login',
            locale: NAMESPACE,
          }, Comp))))

        guarded('settings.plugin.item', () => ctx.slots.inject('settings.plugin.item',
          () => guarded('settings.plugin.item register', () => ctx.slots.register({
            name: 'settings.plugin.item',
            key: '@local/dsh-workbuddy-ai-login',
            priority: 20,
          }, Comp))))
      },
    }
  },
})
