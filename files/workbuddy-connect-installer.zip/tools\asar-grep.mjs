// Scan asar entries' text content for a pattern, print matching file + snippet.
import fs from 'node:fs'

const [, , asarPath, patternArg, maxHitsArg] = process.argv
if (!asarPath || !patternArg) { console.error('usage: asar-grep.mjs <asar> <regex> [maxHits]'); process.exit(1) }
const re = new RegExp(patternArg, 'g')
const maxHits = Number(maxHitsArg || 20)

const fd = fs.openSync(asarPath, 'r')
const head = Buffer.alloc(16)
fs.readSync(fd, head, 0, 16, 0)
const declared = head.readUInt32LE(8)
let slab = Buffer.alloc(declared + 64)
fs.readSync(fd, slab, 0, slab.length, 16)
let jsonEnd = -1
if (slab[0] === 0x7b) {
  let depth = 0, inStr = false, esc = false
  for (let i = 0; i < slab.length; i++) {
    const c = slab[i]
    if (inStr) { if (esc) esc = false; else if (c === 0x5c) esc = true; else if (c === 0x22) inStr = false; continue }
    if (c === 0x22) inStr = true
    else if (c === 0x7b) depth++
    else if (c === 0x7d) { depth--; if (depth === 0) { jsonEnd = i + 1; break } }
  }
}
const header = JSON.parse(slab.subarray(0, jsonEnd).toString('utf8'))
const baseOffset = 16 + jsonEnd
const entries = []
;(function walk(node, prefix) {
  for (const [name, val] of Object.entries(node.files || {})) {
    const p = prefix ? `${prefix}/${name}` : name
    if (val.files) walk(val, p)
    else entries.push({ path: p, size: Number(val.size || 0), offset: Number(val.offset || 0) })
  }
})(header, '')

let hits = 0
for (const e of entries) {
  if (e.size === 0 || e.size > 25 * 1024 * 1024) continue
  if (!/\.(js|mjs|cjs|json|ts|txt|md|yml|yaml|html)$/i.test(e.path)) continue
  const buf = Buffer.alloc(e.size)
  fs.readSync(fd, buf, 0, e.size, baseOffset + e.offset)
  const text = buf.toString('utf8')
  re.lastIndex = 0
  let m
  while ((m = re.exec(text)) !== null) {
    const start = Math.max(0, m.index - 220)
    const snip = text.slice(start, Math.min(text.length, m.index + 320)).replace(/\s+/g, ' ')
    console.log(`\n### ${e.path} @${m.index}\n${snip}`)
    hits++
    if (hits >= maxHits) { console.log(`\n(reached maxHits=${maxHits})`); process.exit(0) }
    if (m[0].length === 0) re.lastIndex++
  }
}
console.log(`\n(total hits ${hits})`)
fs.closeSync(fd)
