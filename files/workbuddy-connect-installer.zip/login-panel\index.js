/**
 * Host half of "WorkBuddy AI Sign-in".
 *
 * Two loopback-only routes back the Settings panel:
 *   GET  /plugins/workbuddy-ai-login/status -> sanitized sign-in state
 *   POST /plugins/workbuddy-ai-login/launch -> starts the desktop app so the
 *                                             user can sign in there
 *
 * The auth file is read ONLY. We never decrypt, never write, and never expose
 * accessToken / refreshToken / nickname to the browser. Only plaintext fields
 * (domain, expiresAt, account.uid, account.type) are used to decide whether a
 * usable WorkBuddy AI sign-in exists — that is exactly what "must be signed in
 * to use" needs, without touching the protected credential material.
 *
 * The actual login is performed by WorkBuddy AI's own desktop app via its
 * official OAuth flow. This plugin deliberately does not implement OAuth:
 * it reuses the desktop sign-in, matching @venshell/dsh-workbuddy-connect.
 */
import fs from 'node:fs'
import path from 'node:path'
import os from 'node:os'
import { spawn } from 'node:child_process'

const STATUS_PATH = '/plugins/workbuddy-ai-login/status'
const LAUNCH_PATH = '/plugins/workbuddy-ai-login/launch'

/** Relative path of the international edition's auth file (Windows). */
const AUTH_RELATIVE = [
  'CodeBuddyExtension', 'Data', 'Public', 'auth', 'workbuddy-desktop-ai.info',
]

/** Candidate install locations for the WorkBuddy AI desktop app (Windows). */
const APP_RELATIVE_CANDIDATES = [
  ['Programs', 'WorkBuddyAI', 'WorkBuddyAI.exe'],
  ['Programs', 'WorkBuddy AI', 'WorkBuddy AI.exe'],
]

function authFileCandidates() {
  const local = process.env.LOCALAPPDATA
  const roaming = process.env.APPDATA
  const out = []
  if (local) out.push(path.join(local, ...AUTH_RELATIVE))
  if (roaming) out.push(path.join(roaming, ...AUTH_RELATIVE))
  // Env override honoured by the connect plugin, kept for parity.
  const override = process.env.WORKBUDDY_AI_AUTH_FILE
  if (override && override.trim()) out.unshift(override.trim())
  return out
}

function appExeCandidates() {
  const local = process.env.LOCALAPPDATA
  if (!local) return []
  const override = process.env.WORKBUDDY_AI_ELECTRON_BIN
  const out = []
  if (override && override.trim()) out.push(override.trim())
  for (const rel of APP_RELATIVE_CANDIDATES) out.push(path.join(local, ...rel))
  return out
}

function json(res, status, body) {
  const payload = JSON.stringify(body)
  res.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'content-length': Buffer.byteLength(payload),
    'cache-control': 'no-store',
  })
  res.end(payload)
}

/** A request is trusted only when it arrives on loopback (same-origin GUI). */
function isLoopback(req) {
  const remote = req.socket?.remoteAddress || req.connection?.remoteAddress || ''
  const host = String(req.headers?.host || '')
  const hostOk = /^(localhost|127\.0\.0\.1|\[::1\])(:\d+)?$/i.test(host)
  return /^(127\.|::1$|::ffff:127\.)/.test(remote) || (hostOk && remote === '')
}

/**
 * Read the auth document and reduce it to a safe sign-in verdict.
 * No secret field ever leaves this function.
 */
function readState() {
  const files = authFileCandidates()
  const checked = []
  for (const file of files) {
    let text
    try {
      text = fs.readFileSync(file, 'utf8')
    } catch (error) {
      checked.push({ file, error: error?.code || 'unreadable' })
      continue
    }
    let doc
    try { doc = JSON.parse(text) } catch {
      checked.push({ file, error: 'invalid-json' })
      continue
    }
    const auth = doc?.auth && typeof doc.auth === 'object' ? doc.auth : {}
    const account = doc?.account && typeof doc.account === 'object' ? doc.account : {}
    const domain = typeof auth.domain === 'string' ? auth.domain : ''
    const isInternational = domain === 'workbuddy.ai' || domain.endsWith('.workbuddy.ai')
    const hasToken = Object.prototype.hasOwnProperty.call(auth, 'accessToken') && auth.accessToken != null
    const expiresAt = Number(auth.expiresAt) || 0
    const expired = expiresAt > 0 && expiresAt <= Date.now()
    const signedIn = isInternational && hasToken && !expired
    return {
      signedIn,
      reason: signedIn ? undefined
        : !isInternational ? 'wrong-edition'
        : !hasToken ? 'no-credential'
        : 'expired',
      domain: domain || undefined,
      appName: 'WorkBuddy AI',
      accountType: typeof account.type === 'string' ? account.type : undefined,
      // A short, non-identifying hint only. Full uid is not needed in the UI.
      accountHint: typeof account.uid === 'string' && account.uid.length >= 8
        ? account.uid.slice(0, 8) : undefined,
      expiresAt: expiresAt || undefined,
      authFile: file,
      checked,
    }
  }
  return { signedIn: false, reason: 'no-credential', appName: 'WorkBuddy AI', checked }
}

function statusHandler() {
  return (req, res) => {
    if (req.method !== 'GET') return json(res, 405, { error: 'method-not-allowed' })
    if (!isLoopback(req)) return json(res, 403, { error: 'request-not-trusted' })
    try { json(res, 200, readState()) } catch (error) {
      json(res, 500, { error: String(error?.message || error) })
    }
  }
}

function launchHandler() {
  return (req, res) => {
    if (req.method !== 'POST') return json(res, 405, { error: 'method-not-allowed' })
    if (!isLoopback(req)) return json(res, 403, { error: 'request-not-trusted' })
    const exe = appExeCandidates().find((p) => { try { return fs.statSync(p).isFile() } catch { return false } })
    if (!exe) {
      return json(res, 200, {
        launched: false,
        error: 'app-not-found',
        message: 'WorkBuddy AI desktop app was not found. Install it, then sign in there.',
      })
    }
    try {
      // Detached so closing DSH does not kill the app; stdio ignored.
      const child = spawn(exe, [], { detached: true, stdio: 'ignore', windowsHide: false })
      child.on('error', () => {})
      child.unref()
      return json(res, 200, { launched: true })
    } catch (error) {
      return json(res, 200, { launched: false, error: 'spawn-failed', message: String(error?.message || error) })
    }
  }
}

export function apply(ctx) {
  const disposers = []
  ctx.inject(['webServer'], (scope) => {
    disposers.push(scope.webServer.register({ kind: 'exact', path: STATUS_PATH, handler: statusHandler() }))
    disposers.push(scope.webServer.register({ kind: 'exact', path: LAUNCH_PATH, handler: launchHandler() }))
  })
  ctx.effect(() => () => { for (const dispose of disposers) { try { dispose() } catch {} } },
    'dsh-workbuddy-ai-login: routes')
}
