const fs = require('node:fs')
const os = require('node:os')
const path = require('node:path')

const AUTH = path.join(os.homedir(), 'AppData', 'Local', 'CodeBuddyExtension', 'Data', 'Public', 'auth')
for (const file of ['workbuddy-desktop-ai.info', 'workbuddy-desktop.info']) {
  const p = path.join(AUTH, file)
  if (!fs.existsSync(p)) { console.log('missing', file); continue }
  const doc = JSON.parse(fs.readFileSync(p, 'utf8'))
  console.log('\n=====', file, 'size', fs.statSync(p).size)
  const shape = (v) => {
    if (typeof v === 'string') return `string(len=${v.length})`
    if (v && typeof v === 'object') {
      if (v.$wbEncrypted) return `ENCRYPTED{${Object.keys(v).join(',')}}`
      return `object{${Object.keys(v).slice(0, 12).join(',')}}`
    }
    return typeof v
  }
  console.log('auth:')
  for (const [k, v] of Object.entries(doc.auth || {})) console.log('   ', k, '=', shape(v))
  console.log('account:', shape(doc.account))
  if (doc.account) for (const [k, v] of Object.entries(doc.account)) {
    const s = shape(v)
    if (s.startsWith('ENCRYPTED') || s.startsWith('string')) console.log('    account.' + k, '=', s)
  }
}
