const fs = require('node:fs')
const f = process.argv[2]
const j = JSON.parse(fs.readFileSync(f, 'utf8'))

console.log('== identity')
for (const k of ['endpoint', 'stagingEndpoint', 'isOversea', 'deploymentType', 'productName', 'applicationName', 'dataFolderName', 'genieVersion', 'commit', 'date']) {
  if (j[k] !== undefined) console.log('  ', k, '=', j[k])
}

console.log('\n== officialEndpoints')
console.log(JSON.stringify(j.officialEndpoints, null, 2)?.slice(0, 1500))

console.log('\n== authentication (keys)')
console.log(Object.keys(j.authentication || {}).join(', '))
console.log('  id =', j.authentication?.id)
console.log('  endpoint =', j.authentication?.endpoint)
console.log('  clientId =', j.authentication?.clientId)
console.log('  scopes =', JSON.stringify(j.authentication?.scopes)?.slice(0, 200))
console.log('  attributes =', JSON.stringify(j.authentication?.attributes)?.slice(0, 600))

console.log('\n== models')
const models = j.models
if (Array.isArray(models)) {
  console.log('count =', models.length)
  for (const m of models.slice(0, 60)) {
    console.log('  ', JSON.stringify({ id: m.id, name: m.name, provider: m.provider, free: m.free, tier: m.tier, credit: m.credit ?? m.credits, type: m.type }).slice(0, 300))
  }
} else if (models && typeof models === 'object') {
  console.log('keys =', Object.keys(models).slice(0, 40).join(', '))
}

console.log('\n== modelTiers')
console.log(JSON.stringify(j.modelTiers)?.slice(0, 1200))
