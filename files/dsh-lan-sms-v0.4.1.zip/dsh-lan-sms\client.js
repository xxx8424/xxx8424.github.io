/**
 * DSH Web 界面里的配对页：只显示一张手机 App 的配对二维码。
 * 二维码由 Host 侧同源路由 /dsh-lan-sms/pair-qr.png 动态生成（令牌变化会自动跟着变）。
 */
window.__ModuleLoader__.load({
  id: 'dsh-lan-sms',
  factory(require) {
    const React = require('react')
    const h = React.createElement
    const PANEL_ID = 'dsh-lan-sms'

    function PairIcon(props) {
      const size = props && props.size ? props.size : 20
      return h(
        'svg',
        {
          viewBox: '0 0 24 24',
          width: size,
          height: size,
          fill: 'none',
          stroke: 'currentColor',
          strokeWidth: 1.6,
          strokeLinecap: 'round',
          strokeLinejoin: 'round',
          'aria-hidden': true,
        },
        h('rect', { x: 3.5, y: 3.5, width: 7, height: 7, rx: 1.5 }),
        h('rect', { x: 13.5, y: 3.5, width: 7, height: 7, rx: 1.5 }),
        h('rect', { x: 3.5, y: 13.5, width: 7, height: 7, rx: 1.5 }),
        h('path', { d: 'M13.5 13.5h3v3h-3zM18.5 17.5v3M16.5 20.5h4' }),
      )
    }

    function PairPage() {
      const src = '/dsh-lan-sms/pair-qr.png?v=' + Date.now()
      return h(
        'div',
        {
          style: {
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
            gap: '18px',
            minHeight: '70vh',
            padding: '32px',
            color: 'var(--dsw-alias-text-primary, #111827)',
          },
        },
        h(
          'div',
          { style: { fontSize: '18px', fontWeight: 600 } },
          'DSH 手机通知 · 配对',
        ),
        h('img', {
          src,
          width: 360,
          height: 360,
          alt: '配对二维码',
          style: {
            width: '360px',
            height: '360px',
            imageRendering: 'pixelated',
            borderRadius: '14px',
            background: '#ffffff',
            padding: '10px',
            boxSizing: 'content-box',
          },
        }),
        h(
          'div',
          { style: { fontSize: '14px', color: 'var(--dsw-alias-text-secondary, #6b7280)' } },
          '用手机 App 扫描二维码完成配对',
        ),
      )
    }

    function apply(ctx) {
      ctx.slots.inject('sidebar.panellist', () =>
        ctx.slots.register(
          { name: 'sidebar.panellist', id: PANEL_ID, order: 40, label: () => '手机配对' },
          PairIcon,
        ),
      )
      ctx.slots.inject('main', () =>
        ctx.slots.register({ name: 'main', key: PANEL_ID }, PairPage),
      )
    }

    return { inject: ['slots'], apply }
  },
})
