# dsh-lan-sms · 任务完成 → 手机弹通知（纯局域网）

每轮任务结束（或出错）时，DSH 把一条提醒推到**已配对的手机 App**，手机顶部弹出通知（带声音/震动）：人回电脑前看结果、改需求，AI 继续干活——干完再响一次。

- **配对一次，永久使用**：DSH 侧显示一张二维码，手机 App 扫一次即完成配对；之后 App 常驻后台长轮询，DSH 重启、IP 不变都不用重新配。
- **纯局域网**：手机与电脑同一 Wi-Fi 即可，消息不出内网；没有互联网也能用。
- **二维码内置在 DSH 界面里**：侧边栏「手机配对」图标 → 主面板只显示一张二维码，不需要复制链接到浏览器。

## 组成

| 部分 | 位置 | 作用 |
|---|---|---|
| DSH Host 插件 | `dsh-lan-sms/index.js` | 监听 `agent/turn-stopping` / `agent/error`，把消息推进配对服务的队列 |
| 配对/推送服务 | `dsh-lan-sms/pairing.js`（端口 8090） | 二维码配对、长轮询 `/dsh/api/poll`、设备状态 |
| DSH 界面页 | `dsh-lan-sms/client.js` | 侧边栏入口 + 只显示二维码的主面板 |
| 手机 App | `assets/app.apk` | 扫码配对、前台服务长轮询、系统通知 |

手机端安装包见下方「下载」。

## 配对流程

1. DSH 里点侧边栏「手机配对」→ 主面板出现二维码（内容 `dshnotify://pair?u=http://<电脑IP>:8090&t=<令牌>&n=<电脑名>`）。
2. 手机 App 点「扫描电脑二维码」→ 扫到后自动保存服务地址与令牌，并调用 `/dsh/api/hello` 校验。
3. 校验通过即配对完成，App 启动前台服务开始长轮询。
4. 之后每轮任务结束，DSH 推送 → App 弹通知。

## 接口（摘要）

- `GET /dsh/api/hello?token=&device=` 校验令牌
- `GET /dsh/api/poll?token=&device=&since=&wait=25` 长轮询取消息
- `POST /dsh/api/test?token=` 推一条测试消息
- `GET /dsh/api/pair` 返回当前配对深链（调试用）
- `GET /app.apk` 下载手机 App 安装包
- `GET /` 手机浏览器兜底页（同一张二维码）

## 配置（设置 → 插件 → 任务完成短信提醒）

主要字段：`enabled`、`channel`（默认 `dsh` = 自研 App）、`pairingPort`（8090）、`prefix`、`notifyOnError`、`onlyRootSessions`、`timeoutMs`。

其他通道仍保留：`ntfy` / `smsgate` / `traccar` / `simple` / `bark` / `webhook`，在设置里切换即可。

## 自测

```powershell
# 服务与配对接口
curl http://127.0.0.1:8090/dsh/api/pair
# 让 AI 调 notify_phone_test 工具，或对话里输入 /sms-test
```

> 改了 `client.js` 之后需要**刷新一次 DSH 页面**，新的侧边栏入口才会出现（本机没跑 `pnpm dev:web`，客户端代码不会热更新）。

## 下载

| 平台 | 文件 | 说明 |
|---|---|---|
| 🖥️ 电脑端 skill | [**dsh-lan-sms-v0.4.1.zip**](https://github.com/xxx8424/dsh-lan-sms/releases/download/v0.4.1/dsh-lan-sms-v0.4.1.zip) | DSH 插件包，解压后按 `INSTALL.md` 安装 |
| 📱 安卓端 App | [**app.apk**](https://github.com/xxx8424/dsh-lan-sms/releases/download/v0.4.1/app.apk) | 「DSH 通知」手机端，传到手机点开安装 |

全部文件见 [Releases 页](https://github.com/xxx8424/dsh-lan-sms/releases)。
