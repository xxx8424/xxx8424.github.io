/**
 * dsh-lan-sms — 任务完成后，通过局域网给手机发一条短信/推送通知。
 *
 * 工作原理：DSH 的 `agent/turn-stopping` 事件在每一轮对话结束前触发；插件在该
 * 事件里取到会话标题、工作目录和结束时间，拼成一条短消息，再用 HTTP 发到同一
 * 个局域网里的「短信网关」——通常是手机上的一个 App（例如 Traccar SMS Gateway），
 * 由手机通过 SIM 卡把内容真正发成短信。
 *
 * 除真短信外也支持几个同样走局域网的推送通道（ntfy / Bark / 自定义 webhook），
 * 这样即使手机上没有装短信网关 App，也能先收到提醒。
 *
 * @module dsh-lan-sms
 */
import http from 'node:http'
import https from 'node:https'
import { spawn } from 'node:child_process'
import { basename, dirname, join } from 'node:path'
import { appendFileSync, existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs'
import { randomBytes } from 'node:crypto'
import { hostname } from 'node:os'
import { homedir } from 'node:os'
import { fileURLToPath } from 'node:url'
import z from '@deepseek-ai/schemastery'
import QRCode from 'qrcode'
import { startPairingServer, pairLink } from './pairing.js'
import { createDeviceHub } from './device-api.js'

/** 插件包目录：用来找自带的安装包等资源。 */
const PLUGIN_DIR = dirname(fileURLToPath(import.meta.url))

/**
 * 持久状态目录：放在用户目录而不是插件目录里。
 * 这样升级/重装插件（换一个解压目录）时，配对令牌和云端话题不会变，
 * 手机 App 不需要重新扫码配对。
 */
const STATE_DIR = join(homedir(), '.dsh', 'lan-sms')

/** 读状态文件：优先稳定目录，找不到就尝试从旧版插件目录 .data 迁移过来。 */
function readStateFile(name) {
  try {
    const value = readFileSync(join(STATE_DIR, name), 'utf8').trim()
    if (value) return value
  } catch {
    /* 走迁移 */
  }
  try {
    const legacy = readFileSync(join(PLUGIN_DIR, '.data', name), 'utf8').trim()
    if (legacy) {
      writeStateFile(name, legacy)
      return legacy
    }
  } catch {
    /* 没有旧数据 */
  }
  return ''
}

/** 写状态文件（失败只记录日志，不影响功能）。 */
function writeStateFile(name, value) {
  try {
    mkdirSync(STATE_DIR, { recursive: true })
    writeFileSync(join(STATE_DIR, name), `${value}\n`, 'utf8')
    return true
  } catch (error) {
    logLine(`状态文件 ${name} 写入失败：${error instanceof Error ? error.message : String(error)}`)
    return false
  }
}

/** 唯一值：同一会话在这个时间窗内只提醒一次，避免连发。 */
const MIN_GAP_MS = 3000
/** 短信文案的硬上限，超长会被截断（一条短信约 70 个汉字）。 */
const MAX_TEXT = 320
const CHANNELS = ['dsh', 'ntfy', 'smsgate', 'traccar', 'simple', 'bark', 'webhook']

/** 读取可能被 volatile 包装的配置值（DSH 会把实时字段包成带 get() 的盒子）。 */
function read(source, key, fallback) {
  const raw = source?.[key]
  const value = raw !== null && typeof raw === 'object' && typeof raw.get === 'function' ? raw.get() : raw
  return value === undefined || value === null ? fallback : value
}

/** 把插件配置整理成一个普通对象（每次发送时重新读取，因此设置页改动即时生效）。 */
function resolveConfig(source) {
  const rawTimeout = Number(read(source, 'timeoutMs', 6000))
  const channel = String(read(source, 'channel', 'dsh'))
  const localServer = read(source, 'localServer', true) !== false
  const localPort = Number(read(source, 'localPort', 8085)) || 8085
  const topic = String(read(source, 'topic', 'dsh-notify')).trim() || 'dsh-notify'
  let gatewayUrl = String(read(source, 'gatewayUrl', '')).trim()
  // ntfy 通道优先用本机自带的局域网服务，地址在运行期推导，不需要用户填。
  if (channel === 'ntfy' && localServer) gatewayUrl = `http://127.0.0.1:${localPort}/${topic}`
  if (channel === 'ntfy' && !gatewayUrl) gatewayUrl = `https://ntfy.sh/${topic}`
  return {
    enabled: read(source, 'enabled', true) !== false,
    channel,
    phone: String(read(source, 'phone', '')).trim(),
    gatewayUrl,
    localServer,
    localPort,
    topic,
    mirrorUrl: String(read(source, 'mirrorUrl', '')).trim(),
    downloadUrl: String(read(source, 'downloadUrl', '')).trim(),
    username: String(read(source, 'username', '')),
    password: String(read(source, 'password', '')),
    prefix: String(read(source, 'prefix', '【DSH】')),
    notifyOnError: read(source, 'notifyOnError', true) !== false,
    onlyRootSessions: read(source, 'onlyRootSessions', true) !== false,
    includeDirectory: read(source, 'includeDirectory', true) !== false,
    timeoutMs: Number.isFinite(rawTimeout) ? Math.min(Math.max(rawTimeout, 500), 60_000) : 6000,
  }
}

/** 单次 HTTP 请求；失败时抛出带网关返回体的错误。 */
function request(urlString, options, body, timeoutMs) {
  return new Promise((resolve, reject) => {
    let url
    try {
      url = new URL(urlString)
    } catch {
      reject(new Error(`网关地址无效：${urlString || '(空)'}`))
      return
    }
    const lib = url.protocol === 'https:' ? https : http
    const request_ = lib.request(
      {
        protocol: url.protocol,
        hostname: url.hostname,
        port: url.port || undefined,
        path: `${url.pathname}${url.search}`,
        method: options.method ?? 'POST',
        headers: options.headers ?? {},
        timeout: timeoutMs,
      },
      (response) => {
        let text = ''
        response.setEncoding('utf8')
        response.on('data', (chunk) => {
          if (text.length < 2000) text += chunk
        })
        response.on('end', () => {
          const code = response.statusCode ?? 0
          if (code >= 200 && code < 300) resolve({ statusCode: code, body: text })
          else reject(new Error(`网关返回 HTTP ${code}${text ? `：${text.slice(0, 160)}` : ''}`))
        })
      },
    )
    request_.on('timeout', () => request_.destroy(new Error(`网关 ${timeoutMs}ms 内没有响应`)))
    request_.on('error', (error) => reject(error))
    if (body !== undefined) request_.write(body)
    request_.end()
  })
}

function basicAuth(username, password) {
  return `Basic ${Buffer.from(`${username}:${password}`, 'utf8').toString('base64')}`
}

/**
 * 镜像通道：把同一条提醒再发一份到 ntfy 兼容地址（给 iPhone / 鸿蒙 NEXT / 其他设备用）。
 * 形如 https://ntfy.sh/<topic>，标题走 ?title=，正文走 body，失败只记日志不影响主通道。
 */
async function sendMirror(cfg, title, body) {
  if (!cfg.mirrorUrl) return
  try {
    const url = new URL(cfg.mirrorUrl)
    url.searchParams.set('title', title)
    await request(
      url.toString(),
      {
        method: 'POST',
        headers: {
          'Content-Type': 'text/plain; charset=utf-8',
          Priority: 'high',
          Tags: 'bell',
        },
      },
      body,
      Math.max(cfg.timeoutMs, 8000),
    )
  } catch (error) {
    logLine(`mirror failed: ${error instanceof Error ? error.message : String(error)}`)
  }
}

/** Traccar SMS Gateway：手机 App 的 LOCAL SERVICE，POST / 即发短信（真短信，需中文自测）。 */
async function sendViaTraccar(cfg, text) {
  if (!cfg.gatewayUrl) throw new Error('还没配置短信网关地址（手机 IP + 端口，例如 http://192.168.1.23:8082）')
  if (!cfg.phone) throw new Error('还没配置接收短信的手机号')
  const base = cfg.gatewayUrl.replace(/\/+$/, '')
  const headers = { 'Content-Type': 'application/json; charset=utf-8' }
  // Traccar 的本地服务用的是 App 里那串 token，直接放在 Authorization 里，不带 Basic/Bearer 前缀。
  const token = cfg.password || cfg.username
  if (token) headers.Authorization = token
  const body = JSON.stringify({ to: cfg.phone, message: text })
  const result = await request(`${base}/`, { method: 'POST', headers }, body, cfg.timeoutMs)
  return { detail: `HTTP ${result.statusCode} → ${cfg.phone}` }
}

/** SMSGate（capcom6/android-sms-gateway）：本地服务 POST /message，Basic 认证，中文/emoji 正常。 */
async function sendViaSmsGate(cfg, text) {
  if (!cfg.gatewayUrl) throw new Error('还没配置短信网关地址（手机 IP + 端口，例如 http://192.168.1.23:8080）')
  if (!cfg.phone) throw new Error('还没配置接收短信的手机号')
  const base = cfg.gatewayUrl.replace(/\/+$/, '')
  const endpoint = /\/message$/u.test(base) ? base : `${base}/message`
  const headers = { 'Content-Type': 'application/json; charset=utf-8' }
  if (cfg.username || cfg.password) headers.Authorization = basicAuth(cfg.username, cfg.password)
  const body = JSON.stringify({ textMessage: { text }, phoneNumbers: [cfg.phone] })
  const result = await request(endpoint, { method: 'POST', headers }, body, cfg.timeoutMs)
  return { detail: `HTTP ${result.statusCode} → ${cfg.phone}` }
}

/** Simple SMS Gateway：最简单，POST /send-sms，无认证（仅限可信局域网）。 */
async function sendViaSimple(cfg, text) {
  if (!cfg.gatewayUrl) throw new Error('还没配置短信网关地址（例如 http://192.168.1.23:8080）')
  if (!cfg.phone) throw new Error('还没配置接收短信的手机号')
  const base = cfg.gatewayUrl.replace(/\/+$/, '')
  const endpoint = /\/send-sms$/u.test(base) ? base : `${base}/send-sms`
  const body = JSON.stringify({ phone: cfg.phone, message: text })
  const result = await request(
    endpoint,
    { method: 'POST', headers: { 'Content-Type': 'application/json; charset=utf-8' } },
    body,
    cfg.timeoutMs,
  )
  return { detail: `HTTP ${result.statusCode} → ${cfg.phone}` }
}

/** ntfy：自建在局域网里的推送服务，手机装 ntfy App 订阅同一个 topic。 */
async function sendViaNtfy(cfg, text) {
  if (!cfg.gatewayUrl) throw new Error('还没配置 ntfy 主题地址（例如 http://192.168.1.5:8080/dsh）')
  const result = await request(
    cfg.gatewayUrl,
    { method: 'POST', headers: { 'Content-Type': 'text/plain; charset=utf-8', Priority: 'default' } },
    text,
    cfg.timeoutMs,
  )
  return { detail: `HTTP ${result.statusCode} → ntfy` }
}

/** Bark：iOS 常用的推送服务，支持自建；URL 形如 https://api.day.app/<key>。 */
async function sendViaBark(cfg, text) {
  if (!cfg.gatewayUrl) throw new Error('还没配置 Bark 服务地址（含 device key）')
  const base = cfg.gatewayUrl.replace(/\/+$/, '')
  const title = 'DSH'
  const url = `${base}/${encodeURIComponent(title)}/${encodeURIComponent(text)}?group=dsh`
  const result = await request(url, { method: 'GET' }, undefined, cfg.timeoutMs)
  return { detail: `HTTP ${result.statusCode} → Bark` }
}

/** 自定义 webhook：POST 一份 JSON，适合接自写的转发脚本或别的网关 App。 */
async function sendViaWebhook(cfg, text, meta) {
  if (!cfg.gatewayUrl) throw new Error('还没配置 webhook 地址')
  const payload = JSON.stringify({
    to: cfg.phone,
    title: `${cfg.prefix}${meta.title}`,
    message: text,
    event: meta.event,
    sessionId: meta.sessionId,
    time: new Date().toISOString(),
  })
  const headers = { 'Content-Type': 'application/json; charset=utf-8' }
  if (cfg.username || cfg.password) headers.Authorization = basicAuth(cfg.username, cfg.password)
  const result = await request(cfg.gatewayUrl, { method: 'POST', headers }, payload, cfg.timeoutMs)
  return { detail: `HTTP ${result.statusCode} → webhook` }
}

const DRIVERS = {
  smsgate: sendViaSmsGate,
  traccar: sendViaTraccar,
  simple: sendViaSimple,
  ntfy: sendViaNtfy,
  bark: sendViaBark,
  webhook: sendViaWebhook,
}

/** 发一条消息；返回 { ok, channel, detail }，永不抛出。 */
async function deliver(cfg, text, meta) {
  const channel = DRIVERS[cfg.channel] ? cfg.channel : ''
  if (!channel) {
    return { ok: false, channel: String(cfg.channel), detail: `没有这个通道：${cfg.channel}` }
  }
  try {
    const outcome = await DRIVERS[channel](cfg, text, meta)
    return { ok: true, channel, detail: outcome?.detail ?? '已发送' }
  } catch (error) {
    const detail = error instanceof Error ? error.message : String(error)
    return { ok: false, channel, detail }
  }
}

/** 会话对象（可选服务，取不到就当作没有）。 */
function sessionOf(ctx, agent) {
  try {
    return ctx.get('sessions')?.get(agent.id)
  } catch {
    return undefined
  }
}

/** 会话标题。 */
function titleOf(ctx, session) {
  if (!session) return ''
  try {
    const snapshot = ctx.get('sessionTitle')?.get(session)
    if (typeof snapshot?.title === 'string' && snapshot.title.trim()) return snapshot.title.trim()
  } catch {
    /* 标题只是锦上添花，失败就算了 */
  }
  return ''
}

/** 会话工作目录。 */
function directoryOf(ctx, session) {
  if (!session) return ''
  try {
    const directory = ctx.get('workingDirectory')?.get(session)
    if (typeof directory === 'string' && directory.trim()) return directory.trim()
  } catch {
    /* ignore */
  }
  try {
    const cwd = session?.header?.cwd
    if (typeof cwd === 'string') return cwd
  } catch {
    /* ignore */
  }
  return ''
}

/** 只要根会话（避免每个子代理结束时也轰炸一遍手机）。 */
function isRootAgent(ctx, agent) {
  const agents = ctx.get('agents')
  if (!agents || typeof agents.roots !== 'function') return true
  try {
    return agents.roots().some((candidate) => candidate.id === agent.id)
  } catch {
    return true
  }
}

function clockText(date = new Date()) {
  try {
    return date.toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit', hour12: false })
  } catch {
    return `${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}`
  }
}

function clip(value, limit) {
  const text = String(value ?? '').replace(/\s+/gu, ' ').trim()
  return text.length > limit ? `${text.slice(0, limit - 1)}…` : text
}

/** 拼一条短信正文。withHeader=false 时第一行留给通知标题。 */
function composeText(cfg, kind, parts, withHeader = true) {
  const lines = []
  if (withHeader) {
    if (kind === 'error') {
      lines.push(`${cfg.prefix}任务出错`)
    } else {
      lines.push(`${cfg.prefix}任务完成`)
    }
  }
  if (parts.title) lines.push(`会话：${clip(parts.title, 40)}`)
  if (kind === 'error' && parts.message) lines.push(`错误：${clip(parts.message, 120)}`)
  if (kind !== 'error' && cfg.includeDirectory && parts.directory) lines.push(`目录：${clip(basename(parts.directory), 30)}`)
  lines.push(`时间：${clockText()}`)
  return lines.join('\n').slice(0, MAX_TEXT)
}

/** 电脑显示名（配对页与通知里用）。 */
function machineName() {
  try {
    return String(hostname() || 'DSH')
  } catch {
    return 'DSH'
  }
}

/** 配对令牌：首次生成后落盘，App 配对一次即可长期使用。 */
function loadPairToken() {
  const existing = readStateFile('pair-token.txt')
  if (/^[0-9a-f]{32}$/u.test(existing)) return existing
  const token = randomBytes(16).toString('hex')
  writeStateFile('pair-token.txt', token)
  return token
}

/** 云端话题：给「不在同一 Wi-Fi」的场景用（经 ntfy 公网转发）。 */
function loadCloudTopic(configured) {
  const wanted = String(configured ?? '').trim()
  if (wanted) return wanted
  const existing = readStateFile('cloud-topic.txt')
  if (/^[a-z0-9-]{6,64}$/u.test(existing)) return existing
  const topic = `dsh-${randomBytes(6).toString('hex')}`
  writeStateFile('cloud-topic.txt', topic)
  return topic
}

/** 完成/失败共用的发送入口。 */
function makeNotifier(ctx, config, hub, cloud) {
  const recent = new Map()

  return async function notify(kind, agent, extra = {}) {
    const cfg = resolveConfig(config)
    if (!cfg.enabled) return { ok: false, channel: cfg.channel, detail: '插件已被禁用' }

    const now = Date.now()
    const key = agent?.id ?? 'unknown'
    const last = recent.get(key) ?? 0
    if (!extra.force && now - last < MIN_GAP_MS) {
      return { ok: false, channel: cfg.channel, detail: '刚才已提醒过，跳过重复提醒' }
    }
    recent.set(key, now)

    const session = agent ? sessionOf(ctx, agent) : undefined
    const parts = {
      title: extra.title ?? titleOf(ctx, session),
      directory: directoryOf(ctx, session),
      message: extra.message,
    }
    const heading = kind === 'error' ? '任务出错' : '任务完成'

    // 自研手机 App：进推送队列（同 Wi-Fi 长轮询取走），同时按需发一份到云端话题
    // （手机不在同一网络时也能收到）。
    if (cfg.channel === 'dsh') {
      const body = extra.text ? clip(extra.text, MAX_TEXT) : composeText(cfg, kind, parts, false)
      const title = `${cfg.prefix}${kind === 'test' ? '测试消息' : heading}`
      hub?.push({ title, body })
      const info = cloud?.()
      if (info?.url) {
        void sendMirror({ mirrorUrl: info.url, timeoutMs: cfg.timeoutMs }, title, body)
      }
      return { ok: true, channel: 'dsh', detail: info?.url ? '已推送（局域网 + 云端）' : '已推送到手机 App' }
    }

    const text = extra.text ?? composeText(cfg, kind, parts)
    const result = await deliver(cfg, text, {
      event: kind,
      sessionId: agent?.id,
      title: heading,
    })
    if (!result.ok) {
      ctx.logger?.warn?.(`dsh-lan-sms: 通知发送失败（${result.channel}）：${result.detail}`)
    }
    return result
  }
}

/**
 * 插件入口。
 * @param ctx 插件上下文。
 * @param config Loader 注入的配置（字段可能是 volatile 盒子）。
 */
export function apply(ctx, config = {}) {
  const pairToken = loadPairToken()
  const machine = machineName()
  const cloudTopic = loadCloudTopic(String(read(config, 'cloudTopic', '') ?? ''))
  const cloud = () => {
    const server = String(read(config, 'cloudServer', 'https://ntfy.sh') ?? '').trim().replace(/\/+$/u, '')
    if (!server) return { server: '', topic: cloudTopic, url: '' }
    return { server, topic: cloudTopic, url: `${server}/${cloudTopic}` }
  }
  const hub = createDeviceHub({ tokenOf: () => pairToken, titleOf: () => `DSH · ${machine}` })
  const notify = makeNotifier(ctx, config, hub, cloud)
  {
    const probe = resolveConfig(config)
    logLine(`apply: channel=${probe.channel} enabled=${probe.enabled} pairingPort=${read(config, 'pairingPort', 8090)} token=${pairToken.slice(0, 6)}…`)
  }

  ctx.effect(
    () => {
      const disposers = []
      disposers.push(
        ctx.on('agent/turn-stopping', (payload) => {
          const agent = payload?.agent
          if (!agent) return
          if (!resolveConfig(config).onlyRootSessions || isRootAgent(ctx, agent)) {
            void notify('turn-end', agent, { seconds: payload?.turnSeconds }).catch(() => {})
          }
        }),
      )
      disposers.push(
        ctx.on('agent/error', (payload) => {
          const agent = payload?.agent
          if (!agent) return
          if (!resolveConfig(config).notifyOnError) return
          if (resolveConfig(config).onlyRootSessions && !isRootAgent(ctx, agent)) return
          const error = payload?.error
          const message = error instanceof Error ? error.message : typeof error === 'string' ? error : ''
          void notify('error', agent, { message }).catch(() => {})
        }),
      )
      return () => {
        for (const dispose of disposers.splice(0)) {
          try {
            dispose?.()
          } catch {
            /* ignore */
          }
        }
      }
    },
    'dsh-lan-sms: turn listeners',
  )

  ctx.inject(['tools'], (toolCtx) => {
    toolCtx.effect(
      () =>
        toolCtx.tools.register({
          name: 'notify_phone_test',
          description:
            'Send one test message to the phone configured in the LAN SMS plugin (dsh-lan-sms), to verify that the on-phone SMS gateway is reachable. Optional arguments override settings for this call only.',
          parameters: {
            type: 'object',
            properties: {
              text: { type: 'string', description: 'Message body; omit for a built-in test sentence.' },
              channel: { type: 'string', enum: CHANNELS, description: 'Override the configured channel for this call.' },
              gatewayUrl: { type: 'string', description: 'Override the configured gateway URL for this call.' },
              phone: { type: 'string', description: 'Override the configured recipient phone number for this call.' },
            },
            additionalProperties: false,
          },
          output: {
            schema: {
              type: 'object',
              properties: {
                ok: { type: 'boolean' },
                channel: { type: 'string' },
                detail: { type: 'string' },
              },
              required: ['ok', 'channel', 'detail'],
              additionalProperties: false,
            },
            render: (args, value) => [
              {
                type: 'text',
                text: value.ok
                  ? `测试消息已通过 ${value.channel} 发出：${value.detail}`
                  : `测试消息发送失败（${value.channel}）：${value.detail}`,
              },
            ],
          },
          execute: async (args) => {
            const cfg = resolveConfig(config)
            const overrides = {
              ...cfg,
              channel: args?.channel ? String(args.channel) : cfg.channel,
              gatewayUrl: args?.gatewayUrl ? String(args.gatewayUrl) : cfg.gatewayUrl,
              phone: args?.phone ? String(args.phone) : cfg.phone,
            }
            const text =
              typeof args?.text === 'string' && args.text.trim()
                ? clip(args.text, MAX_TEXT)
                : `${overrides.prefix}这是一条 DSH 局域网短信测试，收到说明通知链路已打通。`
            // 自研 App 通道不经过 HTTP 驱动，直接进推送队列。
            if (overrides.channel === 'dsh') {
              const message = hub?.push({ title: `${overrides.prefix}测试消息`, body: text })
              return { ok: true, channel: 'dsh', detail: message ? `已入队 #${message.id}，手机长轮询取走` : '推送队列不可用' }
            }
            return await deliver(overrides, text, {
              event: 'test',
              sessionId: undefined,
              title: '测试',
            })
          },
        }),
      'dsh-lan-sms: test tool',
    )
  })

  ctx.inject(['commands'], (commandCtx) => {
    commandCtx.effect(
      () =>
        commandCtx.commands.register({
          name: 'sms-test',
          description: '给配置好的手机发一条测试短信，检查局域网短信网关是否通畅。',
          handler: async () => {
            const cfg = resolveConfig(config)
            const result = await notify('test', undefined, {
              force: true,
              title: '测试',
              text: `${cfg.prefix}这是一条 DSH 测试消息，收到说明任务完成提醒已经打通。`,
            })
            return result.ok
              ? { kind: 'success', text: `测试短信已通过 ${result.channel} 发出（${result.detail}）。` }
              : { kind: 'error', text: `测试发送失败（${result.channel}）：${result.detail}` }
          },
        }),
      'dsh-lan-sms: /sms-test command',
    )
  })

  // 纯局域网：插件自己拉起 ntfy 服务端，消息不出内网。
  ctx.effect(() => {
    const settings = resolveConfig(config)
    if (!settings.localServer || settings.channel !== 'ntfy') return () => {}
    const child = startLocalNtfy({
      exe: resolveServerPath(String(read(config, 'serverPath', '') ?? '')),
      port: settings.localPort,
      logger: ctx.logger,
    })
    return () => {
      try {
        child?.kill()
      } catch {
        /* ignore */
      }
    }
  }, 'dsh-lan-sms: local ntfy server')

  // 一次性配对 + 推送服务：手机 App 扫二维码配对，之后靠长轮询收通知。
  ctx.effect(() => {
    const pairing = startPairingServer({
      getConfig: () => {
        const info = cloud()
        return {
          ...resolveConfig(config),
          cloudServer: info.server,
          cloudTopic: info.topic,
          cloudUrl: info.url,
        }
      },
      hub,
      notifyTest: () =>
        notify('test', undefined, {
          force: true,
          text: '如果你在手机上看到这条，说明配对和推送都通了。',
        }),
      tokenOf: () => pairToken,
      nameOf: () => machine,
      port: Number(read(config, 'pairingPort', 8090)) || 8090,
      apkPath: () => resolveApkPath(String(read(config, 'apkPath', '') ?? '')),
    })
    void pairing.ready().then((listening) => {
      if (!listening) throw new Error(`配对服务端口 ${pairing.port} 被占用`)
      logLine(`pairing server up on ${pairing.port}`)
    }).catch((error) => {
      logLine(`pairing server failed: ${error instanceof Error ? error.message : String(error)}`)
    })
    return () => {
      void pairing.dispose()
    }
  }, 'dsh-lan-sms: pairing server')

  // 把二维码画进 DSH 界面里（Web GUI 同源路由），前端只显示这一张图。
  ctx.inject(['webServer'], (webCtx) => {
    webCtx.effect(
      () =>
        webCtx.webServer.register({
          kind: 'exact',
          path: '/dsh-lan-sms/pair-qr.png',
          handler: async (req, res) => {
            const port = Number(read(config, 'pairingPort', 8090)) || 8090
            const link = pairLink({ port, token: pairToken, name: machine, cloudUrl: cloud().url })
            try {
              const png = await QRCode.toBuffer(link, {
                type: 'png',
                width: 420,
                margin: 2,
                errorCorrectionLevel: 'M',
              })
              res.writeHead(200, {
                'Content-Type': 'image/png',
                'Content-Length': png.length,
                'Cache-Control': 'no-store',
              })
              res.end(png)
            } catch (error) {
              res.writeHead(500, { 'Content-Type': 'text/plain; charset=utf-8' })
              res.end(error instanceof Error ? error.message : 'qr failed')
            }
          },
        }),
      'dsh-lan-sms: qr route',
    )
  })
}

/** 插件自己的诊断日志（宿主控制台看不到，方便排查局域网服务是否起来）。 */
function logLine(message) {
  try {
    const directory = join(homedir(), '.dsh', 'lan-sms')
    mkdirSync(directory, { recursive: true })
    appendFileSync(join(directory, 'plugin.log'), `${new Date().toISOString()} ${message}\n`, 'utf8')
  } catch {
    /* 日志失败不影响功能 */
  }
}

/** 插件自带的 ntfy 服务端程序路径。 */
function resolveServerPath(configured) {
  const trimmed = String(configured ?? '').trim()
  if (trimmed) return trimmed
  const bundled = join(PLUGIN_DIR, 'assets', 'ntfy.exe')
  return existsSync(bundled) ? bundled : ''
}

/**
 * 启动插件自带的局域网 ntfy 服务（纯局域网推送，消息不出内网）。
 * @returns 子进程；不可用时返回 undefined。
 */
function startLocalNtfy({ exe, port, logger }) {
  logLine(`start local ntfy: exe=${exe || '(空)'} port=${port}`)
  if (!exe || !existsSync(exe)) {
    logger?.warn?.('dsh-lan-sms: 没找到 ntfy 服务端程序（assets/ntfy.exe），局域网推送不会启动')
    logLine('abort: ntfy.exe 不存在')
    return undefined
  }
  const dataDir = join(PLUGIN_DIR, '.data')
  try {
    mkdirSync(dataDir, { recursive: true })
  } catch {
    /* 缓存目录建不了就让 ntfy 用内存缓存 */
  }
  try {
    const child = spawn(
      exe,
      ['serve', '--listen-http', `0.0.0.0:${port}`, '--cache-file', join(dataDir, 'ntfy-cache.db')],
      { stdio: 'ignore', windowsHide: true },
    )
    logLine(`spawned pid=${child.pid}`)
    child.on('error', (error) => {
      logLine(`spawn error: ${error instanceof Error ? `${error.message} code=${error.code}` : String(error)}`)
      logger?.warn?.(`dsh-lan-sms: 局域网推送服务启动失败：${error instanceof Error ? error.message : String(error)}`)
    })
    child.on('exit', (code, signal) => logLine(`ntfy exited code=${code} signal=${signal}`))
    logger?.info?.(`dsh-lan-sms: 局域网推送服务已启动，端口 ${port}`)
    return child
  } catch (error) {
    logLine(`spawn threw: ${error instanceof Error ? error.message : String(error)}`)
    logger?.warn?.(`dsh-lan-sms: 局域网推送服务启动异常：${error instanceof Error ? error.message : String(error)}`)
    return undefined
  }
}

/** 让缺省值先过一遍：字段标成 volatile 才能在设置页直接改，改完立即生效。 */
function live(schema) {
  const mark = schema?.volatile
  return typeof mark === 'function' ? mark.call(schema) : schema
}

/** 配对页要分发的安装包：配置留空时优先用自研 App，其次插件自带的 ntfy。 */
function resolveApkPath(configured) {
  const trimmed = String(configured ?? '').trim()
  if (trimmed) return trimmed
  const candidates = [
    join(PLUGIN_DIR, 'assets', 'app.apk'),
    join(PLUGIN_DIR, '..', 'phone-notify', 'android-app', 'app.apk'),
    join(PLUGIN_DIR, 'assets', 'ntfy.apk'),
  ]
  for (const candidate of candidates) {
    if (existsSync(candidate)) return candidate
  }
  return ''
}

export const Config = z.object({
  enabled: live(z.boolean().default(true)).description('开启后，每轮任务结束都会给手机发一条提醒。'),
  channel: live(z.union(CHANNELS).default('dsh')).description(
    '通道：dsh = 自研手机 App（纯局域网，推荐）；ntfy = 局域网 ntfy 推送；smsgate / traccar / simple = 手机短信网关（真短信）；bark / webhook = 其他推送。',
  ),
  phone: live(z.string().default('')).description('接收短信的手机号（国际格式，例如 +8613800138000）。'),
  gatewayUrl: live(z.string().default('')).description(
    '网关地址。smsgate 例：http://192.168.1.23:8080；traccar 例：http://192.168.1.23:8082；simple 例：http://192.168.1.23:8080；ntfy 例：http://192.168.1.5:8080/dsh；bark 例：https://api.day.app/<key>。',
  ),
  username: live(z.string().default('')).description('Basic 认证用户名（smsgate 本地服务账号）；traccar 留空即可。'),
  password: live(z.string().default('')).description(
    'Basic 认证密码（smsgate）；traccar 通道这里填 App 显示的本地服务 token；simple 通道不需要。',
  ),
  prefix: live(z.string().default('【DSH】')).description('短信开头的标记文字。'),
  notifyOnError: live(z.boolean().default(true)).description('任务出错时也发一条提醒。'),
  onlyRootSessions: live(z.boolean().default(true)).description('只提醒主会话，忽略子代理的每轮结束。'),
  includeDirectory: live(z.boolean().default(true)).description('短信里带上工作目录名，方便判断是哪个项目。'),
  timeoutMs: live(z.number().default(6000)).description('单次发送的超时时间（毫秒）。'),
  localServer: live(z.boolean().default(true)).description(
    '纯局域网模式：插件自己在电脑上跑一个 ntfy 服务，手机和电脑同一 Wi-Fi 即可收到，消息不出内网。',
  ),
  localPort: live(z.number().default(8085)).description('局域网 ntfy 服务端口（默认 8085）。'),
  topic: live(z.string().default('dsh-notify')).description('推送主题名（相当于口令，改成随机字符串更安全）。'),
  serverPath: live(z.string().default('')).description('ntfy 服务端程序路径；留空则用插件自带 assets/ntfy.exe。'),
  pairingPort: live(z.number().default(8090)).description(
    '配对页端口。电脑上打开 http://127.0.0.1:<端口>/ 看到二维码，手机扫一次就配好；手机也可在这个地址下载安装包。',
  ),
  apkPath: live(z.string().default('')).description('配对页分发的 APK 路径；留空则用插件自带 assets/ntfy.apk。'),
  downloadUrl: live(z.string().default('')).description(
    '网盘/下载页链接（例如你上传 APK 后的分享链接）。设置后：配对页会多一个「网盘下载手机 App」按钮，手机 App 的设置页也会显示「下载/分享 App」入口。',
  ),
  cloudServer: live(z.string().default('https://ntfy.sh')).description(
    '云端转发服务地址（默认 https://ntfy.sh，免费）。用于「手机和电脑不在同一个 Wi-Fi」时也能收到提醒；留空则只用局域网。',
  ),
  cloudTopic: live(z.string().default('')).description(
    '云端话题名（相当于密码）。留空则自动生成并保存在插件目录 .data/cloud-topic.txt，配对二维码会自动带上下发给手机。',
  ),
})
