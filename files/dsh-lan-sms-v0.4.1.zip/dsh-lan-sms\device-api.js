/**
 * 手机 App 的配对/推送接口（协议见 phone-notify/PROTOCOL.md）。
 *
 * 长轮询 + 内存消息队列：插件每轮任务结束时 push 一条，手机 App 挂着
 * `/dsh/api/poll` 就能立刻收到并弹通知。设备连接信息只放内存，重启后
 * App 会自动重连，不需要重新配对。
 */

const MAX_MESSAGES = 200
const MAX_WAIT_MS = 30_000

/**
 * 建立消息中枢。
 * @param options.tokenOf 返回当前配对令牌
 * @param options.titleOf 返回电脑显示名
 */
export function createDeviceHub(options = {}) {
  const tokenOf = options.tokenOf ?? (() => '')
  const titleOf = options.titleOf ?? (() => 'DSH')
  /** @type {Array<{id:number,title:string,body:string,ts:number}>} */
  const messages = []
  // 消息 id 用「Unix 秒」作为起点：插件/DSH 重启后序号不会归零，手机端按 id 去重
  // 就不会把新消息当成「已经弹过的旧消息」而静默丢掉。
  let seq = Math.floor(Date.now() / 1000)
  /** @type {Set<() => void>} */
  const waiters = new Set()
  /** @type {Map<string, {at:number, ip:string|undefined}>} */
  const devices = new Map()
  let lastDevice = undefined

  function push({ title, body, ts }) {
    const message = {
      id: ++seq,
      title: String(title ?? ''),
      body: String(body ?? ''),
      ts: Number(ts ?? Math.floor(Date.now() / 1000)),
    }
    messages.push(message)
    if (messages.length > MAX_MESSAGES) messages.shift()
    for (const wake of [...waiters]) {
      try {
        wake()
      } catch {
        /* ignore */
      }
    }
    return message
  }

  function afterId(since) {
    let from = Number(since ?? 0) || 0
    // 服务重启后序号会归零，而 App 里保存的游标可能更大；此时按“从头发”处理，
    // 否则 App 会一直等 id > 旧游标，永远收不到新消息。
    if (from > seq) from = 0
    return messages.filter((message) => message.id > from)
  }

  function poll({ since, waitMs }) {
    const wait = Math.min(Math.max(Number(waitMs ?? 25) * 1000 || 25_000, 0), MAX_WAIT_MS)
    if (afterId(since).length > 0) {
      return Promise.resolve({ messages: afterId(since), next: seq })
    }
    return new Promise((resolve) => {
      let settled = false
      const finish = () => {
        if (settled) return
        settled = true
        waiters.delete(wake)
        clearTimeout(timer)
        resolve({ messages: afterId(since), next: seq })
      }
      const wake = () => finish()
      const timer = setTimeout(finish, wait)
      waiters.add(wake)
    })
  }

  function noteDevice(device, ip) {
    const key = String(device ?? 'unknown')
    devices.set(key, { at: Date.now(), ip })
    lastDevice = key
  }

  return {
    push,
    poll,
    noteDevice,
    hello(ip) {
      return {
        ok: true,
        server: titleOf(),
        version: 1,
        deviceId: undefined,
        ip,
      }
    },
    status() {
      return {
        ok: true,
        server: titleOf(),
        pending: messages.length,
        lastMessageId: seq,
        devices: [...devices.entries()].map(([id, info]) => ({ id, ...info })),
        lastDevice,
      }
    },
    snapshot(limit = 20) {
      return messages.slice(-limit)
    },
  }
}

/** 解析请求里的查询参数（不依赖 URL 类，保持轻量）。 */
export function queryOf(request) {
  const raw = (request.url ?? '').split('?')[1] ?? ''
  const params = new Map()
  for (const part of raw.split('&')) {
    if (!part) continue
    const index = part.indexOf('=')
    const key = decodeURIComponent(index >= 0 ? part.slice(0, index) : part)
    const value = decodeURIComponent(index >= 0 ? part.slice(index + 1) : '')
    params.set(key, value)
  }
  return {
    get(name, fallback = '') {
      return params.has(name) ? params.get(name) : fallback
    },
  }
}
