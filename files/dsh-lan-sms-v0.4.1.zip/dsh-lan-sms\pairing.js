/**
 * 局域网配对服务：给手机 App 提供配对接口和消息长轮询，
 * 同时提供一个「只有二维码」的配对页（DSH 界面里也会内嵌同一张二维码）。
 *
 * 协议见 phone-notify/PROTOCOL.md。
 *
 * @module dsh-lan-sms/pairing
 */
import http from 'node:http'
import { createReadStream, existsSync, statSync } from 'node:fs'
import { networkInterfaces } from 'node:os'
import QRCode from 'qrcode'
import { queryOf } from './device-api.js'

const PRIVATE = [/^10\./u, /^192\.168\./u, /^172\.(1[6-9]|2\d|3[01])\./u]
const LOOPBACK = new Set(['127.0.0.1', 'localhost', '0.0.0.0', '::1'])

/** 本机局域网 IPv4 地址（过滤回环/链路本地）。 */
export function lanAddresses() {
  const found = []
  for (const [name, list] of Object.entries(networkInterfaces())) {
    for (const entry of list ?? []) {
      if (entry.family !== 'IPv4' || entry.internal) continue
      if (!PRIVATE.some((pattern) => pattern.test(entry.address))) continue
      found.push({ name, address: entry.address })
    }
  }
  return found
}

/**
 * 手机 App 的配对深链：同时带局域网地址与云端话题，App 自己挑可用的一条。
 * 参数：v=协议版本, u=局域网服务地址, t=配对令牌, n=电脑名, c=云端话题 URL
 */
export function pairLink({ addresses, port, token, name, cloudUrl }) {
  const lan = (addresses ?? lanAddresses())[0]
  const host = lan?.address ?? '127.0.0.1'
  const url = `http://${host}:${port}`
  const params = new URLSearchParams({ v: '2', u: url, t: String(token ?? ''), n: String(name ?? 'DSH') })
  if (cloudUrl) params.set('c', String(cloudUrl))
  return `dshnotify://pair?${params.toString()}`
}

function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>"']/gu, (char) => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;',
  })[char])
}

function json(res, status, value) {
  const body = JSON.stringify(value)
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' })
  res.end(body)
}

async function renderPage({ link, hasApk, port, enabled, downloadUrl, cloudUrl }) {
  let qrSvg = ''
  try {
    qrSvg = await QRCode.toString(link, {
      type: 'svg',
      margin: 1,
      width: 300,
      errorCorrectionLevel: 'M',
      color: { dark: '#0f172a', light: '#ffffff' },
    })
  } catch {
    qrSvg = ''
  }
  const cloudLine = cloudUrl
    ? '<p class="hint">已启用云端转发：手机和电脑不在同一个 Wi-Fi 也能收到提醒。</p>'
    : ''
  return `<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>DSH 手机通知 · 配对</title>
<style>
  body { font: 16px/1.7 system-ui, -apple-system, "Segoe UI", "Microsoft YaHei", sans-serif; margin: 0; padding: 32px 20px; background: #f6f7fb; color: #0f172a; text-align: center; }
  .card { display: inline-block; background: #fff; border: 1px solid #e5e7eb; border-radius: 16px; padding: 24px; }
  h1 { font-size: 20px; margin: 0 0 6px; }
  p { margin: 6px 0; color: #6b7280; font-size: 14px; }
  p.hint { color: #2563eb; }
  svg { width: 300px; height: 300px; display: block; margin: 12px auto; }
  a.button { display: inline-block; margin-top: 10px; background: #2563eb; color: #fff; text-decoration: none; padding: 10px 18px; border-radius: 10px; font-weight: 600; }
  code { background: #eef1f6; border-radius: 6px; padding: 1px 6px; font-size: 13px; word-break: break-all; }
  .off { color: #b91c1c; }
</style></head>
<body><div class="card">
  <h1>DSH 手机通知</h1>
  <p>用手机 App 扫描下方二维码完成配对</p>
  ${enabled ? '' : '<p class="off">插件当前已停用</p>'}
  ${cloudLine}
  ${qrSvg}
  <p><code>${escapeHtml(link)}</code></p>
  <p>服务端口 <code>${port}</code></p>
  ${hasApk ? `<a class="button" href="/app.apk">下载手机 App（${escapeHtml(hasApk.label)}，同一 Wi-Fi）</a>` : ''}
  ${downloadUrl ? `<p style="margin-top:14px">其他设备 / 不在同一 Wi-Fi：</p><a class="button" href="${escapeHtml(downloadUrl)}">网盘下载手机 App</a>` : ''}
</div></body></html>`
}

/**
 * 启动配对/推送服务。
 * @param options.getConfig 读取当前配置（含 cloudServer / cloudTopic / downloadUrl）
 * @param options.hub 设备消息中枢
 * @param options.tokenOf 返回当前配对令牌
 * @param options.nameOf 返回电脑显示名
 * @param options.port 监听端口
 * @param options.apkPath 手机 App 安装包路径
 */
export function startPairingServer(options = {}) {
  const getConfig = options.getConfig ?? (() => ({}))
  const hub = options.hub
  const tokenOf = options.tokenOf ?? (() => '')
  const nameOf = options.nameOf ?? (() => 'DSH')
  const port = Number(options.port ?? 8090)
  const apkPathOf = options.apkPath ?? (() => '')

  function cloudUrlOf() {
    const cfg = getConfig()
    const server = String(cfg.cloudServer ?? '').trim().replace(/\/+$/u, '')
    const topic = String(cfg.cloudTopic ?? '').trim()
    if (!server || !topic) return ''
    return server + '/' + topic
  }

  function authorized(query) {
    const given = String(query.get('token', '') ?? '')
    const expected = String(tokenOf() ?? '')
    return expected !== '' && given === expected
  }

  const server = http.createServer(async (req, res) => {
    const path = (req.url ?? '/').split('?')[0]
    const query = queryOf(req)

    try {
      if (path === '/dsh/api/hello') {
        if (!authorized(query)) return json(res, 401, { ok: false, error: 'token' })
        const device = query.get('device', '')
        if (device) hub?.noteDevice(device, req.socket?.remoteAddress)
        return json(res, 200, {
          ...hub?.hello(req.socket?.remoteAddress),
          downloadUrl: String(getConfig().downloadUrl ?? ''),
          cloudUrl: cloudUrlOf(),
          token: undefined,
        })
      }

      if (path === '/dsh/api/poll') {
        if (!authorized(query)) return json(res, 401, { ok: false, error: 'token' })
        const device = query.get('device', '')
        if (device) hub?.noteDevice(device, req.socket?.remoteAddress)
        const result = await hub.poll({ since: query.get('since', '0'), waitMs: query.get('wait', '25') })
        return json(res, 200, result)
      }

      if (path === '/dsh/api/ping') {
        if (!authorized(query)) return json(res, 401, { ok: false, error: 'token' })
        hub?.noteDevice(query.get('device', ''), req.socket?.remoteAddress)
        return json(res, 200, { ok: true })
      }

      if (path === '/dsh/api/test') {
        if (!authorized(query)) return json(res, 401, { ok: false, error: 'token' })
        if (typeof options.notifyTest === 'function') {
          const result = await options.notifyTest()
          return json(res, 200, { ok: true, delivered: result })
        }
        const message = hub?.push({
          title: '【DSH】测试消息',
          body: '如果你在手机上看到这条，说明配对和推送都通了。',
        })
        return json(res, 200, { ok: true, message })
      }

      if (path === '/dsh/api/status') {
        if (!authorized(query)) return json(res, 401, { ok: false, error: 'token' })
        return json(res, 200, {
          ...hub?.status(),
          link: pairLink({ port, token: tokenOf(), name: nameOf(), cloudUrl: cloudUrlOf() }),
        })
      }

      if (path === '/dsh/api/pair') {
        return json(res, 200, {
          ok: true,
          link: pairLink({ port, token: tokenOf(), name: nameOf(), cloudUrl: cloudUrlOf() }),
        })
      }

      if (path === '/app.apk') {
        const apkPath = String(apkPathOf() ?? '')
        if (!apkPath || !existsSync(apkPath)) {
          res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }).end('安装包还没准备好')
          return
        }
        const info = statSync(apkPath)
        res.writeHead(200, {
          'Content-Type': 'application/vnd.android.package-archive',
          'Content-Length': info.size,
          'Content-Disposition': `attachment; filename="${apkPath.split(/[\\/]/u).pop()}"`,
        })
        createReadStream(apkPath).pipe(res)
        return
      }

      if (path === '/' || path === '/index.html') {
        const apkPath = String(apkPathOf() ?? '')
        const hasApk = apkPath && existsSync(apkPath)
          ? { label: `${(statSync(apkPath).size / 1024 / 1024).toFixed(1)} MB` }
          : undefined
        const html = await renderPage({
          link: pairLink({ port, token: tokenOf(), name: nameOf(), cloudUrl: cloudUrlOf() }),
          hasApk,
          port,
          enabled: getConfig().enabled !== false,
          downloadUrl: String(getConfig().downloadUrl ?? '').trim(),
          cloudUrl: cloudUrlOf(),
        })
        res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' })
        res.end(html)
        return
      }

      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }).end('not found')
    } catch (error) {
      json(res, 500, { ok: false, error: error instanceof Error ? error.message : String(error) })
    }
  })

  const ready = new Promise((resolve) => {
    server.once('listening', () => resolve(true))
    server.once('error', () => resolve(false))
    server.listen(port, '0.0.0.0')
  })

  return {
    port,
    addresses: lanAddresses(),
    ready: () => ready,
    dispose: () => new Promise((resolve) => server.close(() => resolve(true))),
  }
}
