/**
 * 抖音自动续火花 —— 每天定时发送一个 🔥
 * ---------------------------------------------------------------
 * 基于 GitHub 开源项目：KID-1912/autojs6-douyin-sendMessage
 *   https://github.com/KID-1912/autojs6-douyin-sendMessage
 * 运行宿主（开源）：SuperMonster003/AutoJs6
 *   https://github.com/SuperMonster003/AutoJs6
 *
 * 相对原脚本的改动：
 *   1. 去掉随机一言，每天只发一条表情消息（🔥）
 *   2. 内置「每日定时守护」，运行一次即可长期生效，当天最多发一次
 *   3. 选择器改为多重回退 + 超时轮询，降低抖音版本更新导致的失效
 *   4. 去掉原有的强制停止抖音（易在不同品牌上卡死），改为回桌面
 *
 * 仅供个人学习自用，请遵守《抖音用户服务协议》，风险自负。
 */

"auto";

// ======================== 配置区（只改这里）========================
var friendName     = "在这里填好友的完整抖音昵称"; // 必须与抖音消息列表显示的一字不差
var password       = "";                          // 锁屏数字密码；留空 = 不自动解锁
var messageText    = "🔥";                        // 每天发送的内容，可换成 "[火花]"、"[加一]" 等
var targetHour     = 8;                           // 每天几点发送（24 小时制）
var targetMinute   = 0;                           // 几分
var usePinnedFirst = false;                       // true = 昵称找不到时点消息列表顶部第一个会话（需先置顶该好友）
var runMode        = "daemon";                    // "daemon" = 常驻守护（点一次运行即可）; "once" = 只发一次（配合 AutoJs6 内置定时任务）
var killAppAfter   = false;                       // 发送后是否强制停止抖音，建议 false
// 「今天已发」的记录存在 App 私有存储里，不依赖外部存储权限
// ==================================================================

var DOUYIN_PKG = "com.ss.android.ugc.aweme";
var MAX_RETRY_PER_DAY = 5;

if (runMode === "once") {
    sendOnce();
    exit();
} else {
    daemon();
}

/* ------------------------------------------------------------------
 * 每日守护：到点后当天只发一次；开机晚了也能在当天补发
 * ------------------------------------------------------------------ */
function daemon() {
    var lastSentDate = readLastDate();
    var failCount = 0;
    toast("火花守护已启动 · 每天 " + pad(targetHour) + ":" + pad(targetMinute) + " 发送 " + messageText);
    log("火花守护启动，上次发送日期：" + (lastSentDate || "无"));

    while (true) {
        try {
            var now = new Date();
            var today = dateStr(now);
            var minutesNow = now.getHours() * 60 + now.getMinutes();
            var minutesTarget = targetHour * 60 + targetMinute;

            if (lastSentDate !== today && minutesNow >= minutesTarget && failCount < MAX_RETRY_PER_DAY) {
                log("到达发送时间，开始执行");
                var ok = sendOnce();
                if (ok) {
                    lastSentDate = today;      // 先写内存，防止状态文件写不进去导致重复发送
                    writeLastDate(today);
                    failCount = 0;
                    toast("今日火花已续 " + messageText);
                    log("发送成功");
                } else {
                    failCount++;
                    log("发送失败（第 " + failCount + " 次），5 分钟后重试");
                    sleep(5 * 60 * 1000);
                }
            }
        } catch (e) {
            log("守护循环异常：" + e);
        }
        sleep(30 * 1000);
    }
}

/* ------------------------------------------------------------------
 * 单次发送流程，成功返回 true
 * ------------------------------------------------------------------ */
function sendOnce() {
    try {
        // 1. 唤醒 + 解锁（仅数字密码）
        if (!device.isScreenOn()) {
            device.wakeUp();
            sleep(1200);
            swipe(device.width / 2, device.height - 120, device.width / 2, 120, 500);
            sleep(1000);
            if (password) {
                for (var i = 0; i < password.length; i++) {
                    var key = text(password[i]).findOnce();
                    if (!key) { log("未找到锁屏数字键 " + password[i]); return false; }
                    clickWidgetByPosition(key);
                    sleep(200);
                }
                sleep(1200);
            }
        }
        home();
        sleep(1000);
        toast("即将自动发送火花，请勿操作手机");
        sleep(2000);

        // 2. 静音并启动抖音
        try { device.setMusicVolume(0); } catch (e) {}
        try { app.launch(DOUYIN_PKG); } catch (e) { app.launchApp("抖音"); }
        sleep(6000);
        clickIfExists([text("允许"), text("始终允许"), text("仅使用期间允许")]);
        closePopup();

        // 3. 进入「消息」页
        var msgTab = waitAny([
            text("消息").className("android.widget.TextView"),
            desc("消息"),
            text("消息"),
            descContains("消息"),
            textContains("消息")
        ], 10000);
        if (!msgTab) { log("未找到消息页入口"); return false; }
        clickWidgetByPosition(msgTab);
        sleep(3000);
        closePopup();

        // 4. 进入好友会话
        if (!enterFriendChat()) { log("未进入好友会话"); return false; }
        sleep(2500);

        // 5. 输入内容
        var inputBox = waitAny([
            className("android.widget.EditText"),
            className("android.widget.EditText").focused(true)
        ], 8000);
        if (!inputBox) { log("未找到聊天输入框"); return false; }
        clickWidgetByPosition(inputBox);
        sleep(800);
        setText(messageText);
        sleep(1500);

        // 6. 点击发送（找不到按钮时用回车兜底）
        var sendBtn = waitAny([
            desc("发送"), text("发送"), descContains("发送"), textContains("发送")
        ], 5000);
        if (sendBtn) {
            clickWidgetByPosition(sendBtn);
        } else {
            log("未找到发送按钮，尝试回车兜底（请手动确认是否发出）");
            try { KeyCode("KEYCODE_ENTER"); }
            catch (e) { try { shell("input keyevent 66"); } catch (e2) {} }
        }
        sleep(3000);
        log("消息已发送：" + messageText);
        // 乐观返回 true：宁可漏发一天，也绝不因误判导致一天连发多条

        // 7. 收尾
        if (killAppAfter) {
            try { killApp(DOUYIN_PKG); } catch (e) { home(); }
        } else {
            home();
        }
        return true;
    } catch (e) {
        log("发送流程异常：" + e);
        try { home(); } catch (ignored) {}
        return false;
    }
}

/* 进入好友聊天：精确昵称 -> 模糊昵称 -> 滚动再找 -> 置顶第一个会话 */
function enterFriendChat() {
    var selectors = [text(friendName), desc(friendName), textContains(friendName), descContains(friendName)];
    var w = waitAny(selectors, 6000);
    if (!w) {
        swipe(device.width >> 1, device.height * 0.75, device.width >> 1, device.height * 0.30, 400);
        sleep(1500);
        w = waitAny(selectors, 3000);
    }
    if (!w) {
        swipe(device.width >> 1, device.height * 0.25, device.width >> 1, device.height * 0.85, 400);
        sleep(1500);
        w = waitAny(selectors, 3000);
    }
    if (w) {
        clickWidgetByPosition(w);
        return true;
    }
    if (usePinnedFirst) {
        log("按昵称未找到，尝试点击消息列表顶部第一个会话");
        click(device.width / 2, device.height * 0.30);
        sleep(2000);
        return waitAny([className("android.widget.EditText")], 5000) != null;
    }
    return false;
}

/* ------------------------------------------------------------------
 * 通用工具
 * ------------------------------------------------------------------ */
function waitAny(selectors, timeoutMs) {
    var deadline = Date.now() + timeoutMs;
    while (Date.now() < deadline) {
        for (var i = 0; i < selectors.length; i++) {
            try {
                var w = selectors[i].findOnce();
                if (w) return w;
            } catch (e) {}
        }
        sleep(400);
    }
    return null;
}

function clickIfExists(selectors) {
    var w = waitAny(selectors, 1500);
    if (w) { clickWidgetByPosition(w); sleep(800); return true; }
    return false;
}

function clickWidgetByPosition(widget) {
    if (!widget) return false;
    var guard = 0;
    while (!widget.clickable() && guard++ < 8) {
        var parent = widget.parent();
        if (!parent) break;
        widget = parent;
    }
    var b = widget.bounds();
    click(b.centerX() + random(1, 8), b.centerY() + random(1, 8));
    sleep(600);
    return true;
}

function closePopup() {
    clickIfExists([
        textMatches(/(.*拒绝.*|.*关闭.*|.*以后再说.*|.*知道了.*|.*跳过.*)/)
    ]);
    sleep(800);
}

function killApp(packageName) {
    app.openAppSetting(packageName);
    sleep(2500);
    var force = waitAny([textMatches(/(结束运行|强行停止|强制停止)/)], 4000);
    if (force) {
        clickWidgetByPosition(force);
        sleep(1000);
        clickIfExists([textMatches(/(.*确.*|.*定.*)/)]);
    }
    home();
}

function pad(n) { return n < 10 ? "0" + n : "" + n; }
function dateStr(d) { return d.getFullYear() + "-" + pad(d.getMonth() + 1) + "-" + pad(d.getDate()); }
/* 用 AutoJs6 的 storages（SharedPreferences）记录，跨重启持久且无需存储权限；
   万一模块不可用则回退到本地文件 */
var _store = null;
try { _store = storages.create("douyin_spark_daily"); } catch (e) { log("storages 不可用，回退文件记录"); }
var _fallbackPath = "/sdcard/Download/.spark_last_date.txt";

function readLastDate() {
    if (_store) { try { return _store.getString("last", ""); } catch (e) {} }
    try { return files.read(_fallbackPath).trim(); } catch (e) { return ""; }
}
function writeLastDate(s) {
    if (_store) {
        try { _store.put("last", s); return; } catch (e) {}
    }
    try { files.write(_fallbackPath, s); }
    catch (e) { log("记录写入失败（不影响本次发送，但重启后可能补发）：" + e); }
}
